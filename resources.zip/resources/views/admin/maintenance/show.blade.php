@extends('layouts.admin.app')

@section('title', 'Maintenance Request Details')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">

    <div>
        <h1 class="page-title mb-1">
            Maintenance Request Details
        </h1>

        <div class="text-muted">
            View maintenance request information
        </div>
    </div>

    <div>

        <a
            href="{{ route('admin.maintenance.edit', ['maintenance' => $item->id]) }}"
            class="btn btn-primary"
        >
            Edit Request
        </a>

        <a
            href="{{ route('admin.maintenance.index') }}"
            class="btn btn-light ms-2"
        >
            ← Back
        </a>

    </div>

</div>


<div class="row g-4">

    {{-- Main Details --}}
    <div class="col-lg-8">

        <div class="card p-4">

            <div class="d-flex justify-content-between align-items-start mb-4">

                <div>

                    <h4 class="mb-1">
                        {{ $item->title }}
                    </h4>

                    <div class="text-muted">
                        Request #{{ $item->id }}
                    </div>

                </div>


                <div>

                    @switch($item->status)

                        @case('open')

                            <span class="badge bg-danger fs-6">
                                Open
                            </span>

                            @break

                        @case('in_progress')

                            <span class="badge bg-warning text-dark fs-6">
                                In Progress
                            </span>

                            @break

                        @case('completed')

                            <span class="badge bg-success fs-6">
                                Completed
                            </span>

                            @break

                        @case('cancelled')

                            <span class="badge bg-secondary fs-6">
                                Cancelled
                            </span>

                            @break

                        @default

                            <span class="badge bg-secondary fs-6">
                                {{ ucfirst($item->status ?? '-') }}
                            </span>

                    @endswitch

                </div>

            </div>


            <div class="row g-4">

                {{-- Priority --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Priority
                    </div>

                    <div class="mt-1">

                        @switch($item->priority)

                            @case('low')

                                <span class="badge bg-secondary">
                                    Low
                                </span>

                                @break

                            @case('medium')

                                <span class="badge bg-info text-dark">
                                    Medium
                                </span>

                                @break

                            @case('high')

                                <span class="badge bg-warning text-dark">
                                    High
                                </span>

                                @break

                            @case('urgent')

                                <span class="badge bg-danger">
                                    Urgent
                                </span>

                                @break

                            @default

                                <span class="text-muted">
                                    -
                                </span>

                        @endswitch

                    </div>

                </div>


                {{-- Assigned To --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Assigned To
                    </div>

                    <div class="fw-semibold">
                        {{ $item->assigned_to ?? '-' }}
                    </div>

                </div>


                {{-- Property --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Property
                    </div>

                    <div class="fw-semibold">

                        @if($item->property)

                            {{ $item->property->name }}

                            @if($item->property->property_code)

                                <div class="text-muted small">
                                    {{ $item->property->property_code }}
                                </div>

                            @endif

                        @elseif($item->property_id)

                            Property #{{ $item->property_id }}

                        @else

                            -

                        @endif

                    </div>

                </div>


                {{-- Unit --}}
                <!-- <div class="col-md-6">

                    <div class="text-muted small">
                        Unit
                    </div>

                    <div class="fw-semibold">

                        @if($item->unit)

                            {{ $item->unit->name
                                ?? $item->unit->unit_number
                                ?? 'Unit #' . $item->unit->id
                            }}

                        @elseif($item->unit_id)

                            Unit #{{ $item->unit_id }}

                        @else

                            -

                        @endif

                    </div>

                </div> -->


                {{-- Tenant --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Tenant
                    </div>

                    <div class="fw-semibold">

                        @if($item->tenant)

                            {{ $item->tenant->name }}

                        @elseif($item->tenant_id)

                            Tenant #{{ $item->tenant_id }}

                        @else

                            -

                        @endif

                    </div>

                </div>


                {{-- Tenant Phone --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Tenant Phone
                    </div>

                    <div class="fw-semibold">

                        {{ $item->tenant?->phone ?? '-' }}

                    </div>

                </div>


                {{-- Completed At --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Completed At
                    </div>

                    <div class="fw-semibold">

                        {{ $item->completed_at
                            ? \Carbon\Carbon::parse($item->completed_at)->format('d M Y, h:i A')
                            : '-'
                        }}

                    </div>

                </div>


                {{-- Created --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Created At
                    </div>

                    <div class="fw-semibold">

                        {{ $item->created_at?->format('d M Y, h:i A') ?? '-' }}

                    </div>

                </div>


                {{-- Description --}}
                <div class="col-md-12">

                    <div class="text-muted small mb-2">
                        Description
                    </div>

                    <div class="border rounded p-3 bg-light">

                        @if($item->description)

                            {!! nl2br(e($item->description)) !!}

                        @else

                            <span class="text-muted">
                                No description provided.
                            </span>

                        @endif

                    </div>

                </div>

            </div>

        </div>

    </div>


    {{-- Sidebar --}}
    <div class="col-lg-4">


        {{-- Quick Actions --}}
        <div class="card p-4">

            <h5 class="mb-3">
                Quick Actions
            </h5>

            <div class="d-grid gap-2">

                <a
                    href="{{ route('admin.maintenance.edit', ['maintenance' => $item->id]) }}"
                    class="btn btn-outline-primary"
                >
                    Edit Request
                </a>


                @if($item->tenant?->phone)

                    <a
                        href="tel:{{ $item->tenant->phone }}"
                        class="btn btn-outline-success"
                    >
                        Call Tenant
                    </a>

                @endif


                @if($item->tenant?->email)

                    <a
                        href="mailto:{{ $item->tenant->email }}"
                        class="btn btn-outline-info"
                    >
                        Email Tenant
                    </a>

                @endif


                <form
                    method="POST"
                    action="{{ route('admin.maintenance.destroy', ['maintenance' => $item->id]) }}"
                    onsubmit="return confirm('Are you sure you want to delete this maintenance request?')"
                >

                    @csrf

                    @method('DELETE')

                    <button
                        type="submit"
                        class="btn btn-outline-danger w-100"
                    >
                        Delete Request
                    </button>

                </form>

            </div>

        </div>


        {{-- Request Summary --}}
        <div class="card p-4 mt-4">

            <h5 class="mb-3">
                Request Summary
            </h5>


            <div class="d-flex justify-content-between mb-3">

                <span class="text-muted">
                    Request ID
                </span>

                <strong>
                    #{{ $item->id }}
                </strong>

            </div>


            <div class="d-flex justify-content-between mb-3">

                <span class="text-muted">
                    Priority
                </span>

                <strong>
                    {{ ucfirst($item->priority ?? '-') }}
                </strong>

            </div>


            <div class="d-flex justify-content-between">

                <span class="text-muted">
                    Status
                </span>

                <strong>
                    {{ ucwords(str_replace('_', ' ', $item->status ?? '-')) }}
                </strong>

            </div>

        </div>


        {{-- Record Information --}}
        <div class="card p-4 mt-4">

            <h5 class="mb-3">
                Record Information
            </h5>


            <div class="mb-3">

                <div class="text-muted small">
                    Created
                </div>

                <strong>
                    {{ $item->created_at?->format('d M Y, h:i A') ?? '-' }}
                </strong>

            </div>


            <div>

                <div class="text-muted small">
                    Last Updated
                </div>

                <strong>
                    {{ $item->updated_at?->format('d M Y, h:i A') ?? '-' }}
                </strong>

            </div>

        </div>

    </div>

</div>

@endsection