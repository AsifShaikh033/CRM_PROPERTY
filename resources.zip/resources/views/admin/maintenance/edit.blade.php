@extends('layouts.admin.app')

@section('title', 'Edit Maintenance Request')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">

    <div>
        <h1 class="page-title mb-1">
            Edit Maintenance Request
        </h1>

        <div class="text-muted">
            Update maintenance request information
        </div>
    </div>

    <div>

        <a
            href="{{ route('admin.maintenance.show', ['maintenance' => $item->id]) }}"
            class="btn btn-outline-primary"
        >
            View Request
        </a>

        <a
            href="{{ route('admin.maintenance.index') }}"
            class="btn btn-light ms-2"
        >
            ← Back
        </a>

    </div>

</div>


<form
    method="POST"
    action="{{ route('admin.maintenance.update', ['maintenance' => $item->id]) }}"
>

    @csrf

    @method('PUT')


    <div class="card p-4">

        <div class="row g-3">


            {{-- Title --}}
            <div class="col-md-8">

                <label class="form-label">
                    Maintenance Title
                    <span class="text-danger">*</span>
                </label>

                <input
                    type="text"
                    name="title"
                    value="{{ old('title', $item->title) }}"
                    class="form-control @error('title') is-invalid @enderror"
                    placeholder="e.g. Plumbing Repair, AC Not Working"
                    required
                >

                @error('title')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Priority --}}
            <div class="col-md-4">

                <label class="form-label">
                    Priority
                    <span class="text-danger">*</span>
                </label>

                <select
                    name="priority"
                    class="form-select @error('priority') is-invalid @enderror"
                    required
                >

                    <option value="">
                        Select Priority
                    </option>

                    <option
                        value="low"
                        {{ old('priority', $item->priority) == 'low' ? 'selected' : '' }}
                    >
                        Low
                    </option>

                    <option
                        value="medium"
                        {{ old('priority', $item->priority) == 'medium' ? 'selected' : '' }}
                    >
                        Medium
                    </option>

                    <option
                        value="high"
                        {{ old('priority', $item->priority) == 'high' ? 'selected' : '' }}
                    >
                        High
                    </option>

                    <option
                        value="urgent"
                        {{ old('priority', $item->priority) == 'urgent' ? 'selected' : '' }}
                    >
                        Urgent
                    </option>

                </select>

                @error('priority')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Property --}}
            <div class="col-md-6">

                <label class="form-label">
                    Property
                </label>

                <select
                    name="property_id"
                    class="form-select @error('property_id') is-invalid @enderror"
                >

                    <option value="">
                        Select Property
                    </option>

                    @foreach ($properties ?? [] as $property)

                        <option
                            value="{{ $property->id }}"
                            {{ old('property_id', $item->property_id) == $property->id ? 'selected' : '' }}
                        >

                            {{ $property->name }}

                            @if($property->property_code)
                                ({{ $property->property_code }})
                            @endif

                        </option>

                    @endforeach

                </select>

                @error('property_id')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Unit --}}
            <!-- <div class="col-md-6">

                <label class="form-label">
                    Unit
                </label>

                <select
                    name="unit_id"
                    class="form-select @error('unit_id') is-invalid @enderror"
                >

                    <option value="">
                        Select Unit
                    </option>

                    @foreach ($units ?? [] as $unit)

                        <option
                            value="{{ $unit->id }}"
                            {{ old('unit_id', $item->unit_id) == $unit->id ? 'selected' : '' }}
                        >

                            {{ $unit->name ?? $unit->unit_number ?? 'Unit #' . $unit->id }}

                        </option>

                    @endforeach

                </select>

                @error('unit_id')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div> -->


            {{-- Tenant --}}
            <div class="col-md-6">

                <label class="form-label">
                    Tenant
                </label>

                <select
                    name="tenant_id"
                    class="form-select @error('tenant_id') is-invalid @enderror"
                >

                    <option value="">
                        Select Tenant
                    </option>

                    @foreach ($tenants ?? [] as $tenant)

                        <option
                            value="{{ $tenant->id }}"
                            {{ old('tenant_id', $item->tenant_id) == $tenant->id ? 'selected' : '' }}
                        >

                            {{ $tenant->name }}

                            @if($tenant->phone)
                                - {{ $tenant->phone }}
                            @endif

                        </option>

                    @endforeach

                </select>

                @error('tenant_id')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Assigned To --}}
            <div class="col-md-6">

                <label class="form-label">
                    Assigned To
                </label>

                <input
                    type="text"
                    name="assigned_to"
                    value="{{ old('assigned_to', $item->assigned_to) }}"
                    class="form-control @error('assigned_to') is-invalid @enderror"
                    placeholder="Technician / Vendor / Staff name"
                >

                @error('assigned_to')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Status --}}
            <div class="col-md-6">

                <label class="form-label">
                    Status
                    <span class="text-danger">*</span>
                </label>

                <select
                    name="status"
                    class="form-select @error('status') is-invalid @enderror"
                    required
                >

                    <option
                        value="open"
                        {{ old('status', $item->status) == 'open' ? 'selected' : '' }}
                    >
                        Open
                    </option>

                    <option
                        value="in_progress"
                        {{ old('status', $item->status) == 'in_progress' ? 'selected' : '' }}
                    >
                        In Progress
                    </option>

                    <option
                        value="completed"
                        {{ old('status', $item->status) == 'completed' ? 'selected' : '' }}
                    >
                        Completed
                    </option>

                    <option
                        value="cancelled"
                        {{ old('status', $item->status) == 'cancelled' ? 'selected' : '' }}
                    >
                        Cancelled
                    </option>

                </select>

                @error('status')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Completed At --}}
            <div class="col-md-6">

                <label class="form-label">
                    Completed At
                </label>

                <input
                    type="datetime-local"
                    name="completed_at"
                    value="{{ old(
                        'completed_at',
                        $item->completed_at
                            ? \Carbon\Carbon::parse($item->completed_at)->format('Y-m-d\TH:i')
                            : ''
                    ) }}"
                    class="form-control @error('completed_at') is-invalid @enderror"
                >

                @error('completed_at')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Description --}}
            <div class="col-md-12">

                <label class="form-label">
                    Description
                </label>

                <textarea
                    name="description"
                    rows="5"
                    class="form-control @error('description') is-invalid @enderror"
                    placeholder="Describe the maintenance issue..."
                >{{ old('description', $item->description) }}</textarea>

                @error('description')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>

        </div>


        {{-- Buttons --}}
        <div class="mt-4 pt-3 border-top">

            <button
                type="submit"
                class="btn btn-primary"
            >
                Update Maintenance Request
            </button>

            <a
                href="{{ route('admin.maintenance.index') }}"
                class="btn btn-light ms-2"
            >
                Cancel
            </a>

        </div>

    </div>

</form>

@endsection