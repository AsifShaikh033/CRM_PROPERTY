@extends('layouts.admin.app')

@section('title', 'Maintenance Requests')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">

    <div>

        <h1 class="page-title mb-1">
            Maintenance Requests
        </h1>

        <div class="text-muted">
            Manage property maintenance and repair requests
        </div>

    </div>

    <a
        href="{{ route('admin.maintenance.create') }}"
        class="btn btn-primary"
    >
        + Add Request
    </a>

</div>


<div class="card p-4">

    <div class="table-responsive">

        <table class="table table-hover align-middle">

            <thead>

                <tr>

                    <th>ID</th>

                    <th>Request</th>

                    <th>Property</th>

                    <th>Tenant</th>

                    <th>Priority</th>

                    <th>Status</th>

                    <th>Created</th>

                    <th width="260">Actions</th>

                </tr>

            </thead>


            <tbody>

                @forelse($items as $item)

                    <tr>

                        {{-- ID --}}
                        <td>
                            #{{ $item->id }}
                        </td>


                        {{-- Title --}}
                        <td>

                            <div class="fw-semibold">
                                {{ $item->title }}
                            </div>

                            @if($item->description)

                                <div class="text-muted small">

                                    {{ \Illuminate\Support\Str::limit(
                                        $item->description,
                                        60
                                    ) }}

                                </div>

                            @endif

                        </td>


                        {{-- Property --}}
                        <td>

                            @if($item->property)

                                <div class="fw-semibold">
                                    {{ $item->property->name }}
                                </div>

                                @if($item->property->property_code)

                                    <div class="text-muted small">
                                        {{ $item->property->property_code }}
                                    </div>

                                @endif

                            @elseif($item->property_id)

                                Property #{{ $item->property_id }}

                            @else

                                -

                            @endif

                        </td>


                        {{-- Tenant --}}
                        <td>

                            @if($item->tenant)

                                {{ $item->tenant->name }}

                            @elseif($item->tenant_id)

                                Tenant #{{ $item->tenant_id }}

                            @else

                                -

                            @endif

                        </td>


                        {{-- Priority --}}
                        <td>

                            @switch($item->priority)

                                @case('low')

                                    <span class="badge bg-secondary">
                                        Low
                                    </span>

                                    @break

                                @case('medium')

                                    <span class="badge bg-info text-dark">
                                        Medium
                                    </span>

                                    @break

                                @case('high')

                                    <span class="badge bg-warning text-dark">
                                        High
                                    </span>

                                    @break

                                @case('urgent')

                                    <span class="badge bg-danger">
                                        Urgent
                                    </span>

                                    @break

                                @default

                                    <span class="badge bg-secondary">
                                        -
                                    </span>

                            @endswitch

                        </td>


                        {{-- Status --}}
                        <td>

                            @switch($item->status)

                                @case('open')

                                    <span class="badge bg-danger">
                                        Open
                                    </span>

                                    @break

                                @case('in_progress')

                                    <span class="badge bg-warning text-dark">
                                        In Progress
                                    </span>

                                    @break

                                @case('completed')

                                    <span class="badge bg-success">
                                        Completed
                                    </span>

                                    @break

                                @case('cancelled')

                                    <span class="badge bg-secondary">
                                        Cancelled
                                    </span>

                                    @break

                                @default

                                    <span class="badge bg-secondary">
                                        {{ ucfirst($item->status ?? '-') }}
                                    </span>

                            @endswitch

                        </td>


                        {{-- Created --}}
                        <td>

                            {{ $item->created_at?->format('d M Y') ?? '-' }}

                        </td>


                        {{-- Actions --}}
                        <td>

                            <a
                                href="{{ route('admin.maintenance.show', ['maintenance' => $item->id]) }}"
                                class="btn btn-sm btn-outline-primary"
                            >
                                View
                            </a>


                            <a
                                href="{{ route('admin.maintenance.edit', ['maintenance' => $item->id]) }}"
                                class="btn btn-sm btn-outline-secondary"
                            >
                                Edit
                            </a>


                            <form
                                action="{{ route('admin.maintenance.destroy', ['maintenance' => $item->id]) }}"
                                method="POST"
                                class="d-inline"
                                onsubmit="return confirm('Are you sure you want to delete this maintenance request?')"
                            >

                                @csrf

                                @method('DELETE')

                                <button
                                    type="submit"
                                    class="btn btn-sm btn-outline-danger"
                                >
                                    Delete
                                </button>

                            </form>

                        </td>

                    </tr>

                @empty

                    <tr>

                        <td
                            colspan="8"
                            class="text-center py-5"
                        >

                            <div class="text-muted mb-3">
                                No maintenance requests found.
                            </div>

                            <a
                                href="{{ route('admin.maintenance.create') }}"
                                class="btn btn-primary btn-sm"
                            >
                                + Add Request
                            </a>

                        </td>

                    </tr>

                @endforelse

            </tbody>

        </table>

    </div>


    @if($items->hasPages())

        <div class="mt-3">
            {{ $items->links() }}
        </div>

    @endif

</div>

@endsection