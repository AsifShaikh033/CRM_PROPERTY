@extends('layouts.admin.app')

@section('title', 'Add Lead')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">

    <div>

        <h1 class="page-title mb-1">
            Add Lead
        </h1>

        <div class="text-muted">
            Create a new property lead
        </div>

    </div>

    <a
        href="{{ route('admin.leads.index') }}"
        class="btn btn-light"
    >
        ← Back
    </a>

</div>


<form
    method="POST"
    action="{{ route('admin.leads.store') }}"
>

    @csrf


    <div class="card p-4">

        <div class="row g-3">

            {{-- Lead Name --}}
            <div class="col-md-6">

                <label class="form-label">
                    Lead Name
                    <span class="text-danger">*</span>
                </label>

                <input
                    type="text"
                    name="name"
                    value="{{ old('name') }}"
                    class="form-control @error('name') is-invalid @enderror"
                    placeholder="Enter lead name"
                    required
                >

                @error('name')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Phone --}}
            <div class="col-md-3">

                <label class="form-label">
                    Phone
                </label>

                <input
                    type="text"
                    name="phone"
                    value="{{ old('phone') }}"
                    class="form-control @error('phone') is-invalid @enderror"
                    placeholder="Phone number"
                >

                @error('phone')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Email --}}
            <div class="col-md-3">

                <label class="form-label">
                    Email
                </label>

                <input
                    type="email"
                    name="email"
                    value="{{ old('email') }}"
                    class="form-control @error('email') is-invalid @enderror"
                    placeholder="lead@example.com"
                >

                @error('email')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Property --}}
            <div class="col-md-6">

                <label class="form-label">
                    Interested Property
                </label>

                <select
                    name="property_id"
                    class="form-select @error('property_id') is-invalid @enderror"
                >

                    <option value="">
                        Select Property
                    </option>

                    @foreach ($properties ?? [] as $property)

                        <option
                            value="{{ $property->id }}"
                            {{ old('property_id') == $property->id ? 'selected' : '' }}
                        >
                            {{ $property->name }}
                            @if ($property->property_code)
                                ({{ $property->property_code }})
                            @endif
                        </option>

                    @endforeach

                </select>

                @error('property_id')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Source --}}
            <div class="col-md-3">

                <label class="form-label">
                    Lead Source
                </label>

                <select
                    name="source"
                    class="form-select"
                >

                    <option value="">
                        Select Source
                    </option>

                    <option
                        value="website"
                        {{ old('source') === 'website' ? 'selected' : '' }}
                    >
                        Website
                    </option>

                    <option
                        value="facebook"
                        {{ old('source') === 'facebook' ? 'selected' : '' }}
                    >
                        Facebook
                    </option>

                    <option
                        value="instagram"
                        {{ old('source') === 'instagram' ? 'selected' : '' }}
                    >
                        Instagram
                    </option>

                    <option
                        value="referral"
                        {{ old('source') === 'referral' ? 'selected' : '' }}
                    >
                        Referral
                    </option>

                    <option
                        value="walk-in"
                        {{ old('source') === 'walk-in' ? 'selected' : '' }}
                    >
                        Walk-in
                    </option>

                    <option
                        value="other"
                        {{ old('source') === 'other' ? 'selected' : '' }}
                    >
                        Other
                    </option>

                </select>

            </div>


            {{-- Status --}}
            <div class="col-md-3">

                <label class="form-label">
                    Status
                    <span class="text-danger">*</span>
                </label>

                <select
                    name="status"
                    class="form-select @error('status') is-invalid @enderror"
                    required
                >

                    <option
                        value="new"
                        {{ old('status', 'new') === 'new' ? 'selected' : '' }}
                    >
                        New
                    </option>

                    <option
                        value="contacted"
                        {{ old('status') === 'contacted' ? 'selected' : '' }}
                    >
                        Contacted
                    </option>

                    <option
                        value="qualified"
                        {{ old('status') === 'qualified' ? 'selected' : '' }}
                    >
                        Qualified
                    </option>

                    <option
                        value="converted"
                        {{ old('status') === 'converted' ? 'selected' : '' }}
                    >
                        Converted
                    </option>

                    <option
                        value="lost"
                        {{ old('status') === 'lost' ? 'selected' : '' }}
                    >
                        Lost
                    </option>

                </select>

                @error('status')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Notes --}}
            <div class="col-md-12">

                <label class="form-label">
                    Notes
                </label>

                <textarea
                    name="notes"
                    rows="5"
                    class="form-control @error('notes') is-invalid @enderror"
                    placeholder="Add notes about this lead"
                >{{ old('notes') }}</textarea>

                @error('notes')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>

        </div>


        {{-- Buttons --}}
        <div class="mt-4 pt-3 border-top">

            <button
                type="submit"
                class="btn btn-primary"
            >
                Save Lead
            </button>

            <a
                href="{{ route('admin.leads.index') }}"
                class="btn btn-light ms-2"
            >
                Cancel
            </a>

        </div>

    </div>

</form>

@endsection