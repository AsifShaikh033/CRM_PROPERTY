@extends('layouts.admin.app')

@section('title', 'Lead Details')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">

    <div>
        <h1 class="page-title mb-1">
            Lead Details
        </h1>

        <div class="text-muted">
            View lead information
        </div>
    </div>

    <div>

        <a
            href="{{ route('admin.leads.edit', ['lead' => $item->id]) }}"
            class="btn btn-primary"
        >
            Edit Lead
        </a>

        <a
            href="{{ route('admin.leads.index') }}"
            class="btn btn-light ms-2"
        >
            ← Back
        </a>

    </div>

</div>


<div class="row g-4">

    {{-- Lead Information --}}
    <div class="col-lg-8">

        <div class="card p-4">

            <div class="d-flex justify-content-between align-items-center mb-4">

                <div>
                    <h4 class="mb-1">
                        {{ $item->name ?? '-' }}
                    </h4>

                    <div class="text-muted">
                        Lead #{{ $item->id }}
                    </div>
                </div>


                {{-- Status --}}
                @switch($item->status)

                    @case('new')
                        <span class="badge bg-primary">
                            New
                        </span>
                        @break

                    @case('contacted')
                        <span class="badge bg-info text-dark">
                            Contacted
                        </span>
                        @break

                    @case('qualified')
                        <span class="badge bg-warning text-dark">
                            Qualified
                        </span>
                        @break

                    @case('converted')
                        <span class="badge bg-success">
                            Converted
                        </span>
                        @break

                    @case('lost')
                        <span class="badge bg-danger">
                            Lost
                        </span>
                        @break

                    @default
                        <span class="badge bg-secondary">
                            {{ ucfirst($item->status ?? 'Unknown') }}
                        </span>

                @endswitch

            </div>


            <div class="row g-4">

                {{-- Name --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Lead Name
                    </div>

                    <div class="fw-semibold">
                        {{ $item->name ?? '-' }}
                    </div>

                </div>


                {{-- Phone --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Phone
                    </div>

                    <div class="fw-semibold">
                        {{ $item->phone ?? '-' }}
                    </div>

                </div>


                {{-- Email --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Email
                    </div>

                    <div class="fw-semibold">
                        {{ $item->email ?? '-' }}
                    </div>

                </div>


                {{-- Source --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Lead Source
                    </div>

                    <div class="fw-semibold">
                        {{ $item->source ? ucfirst($item->source) : '-' }}
                    </div>

                </div>


                {{-- Property --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Interested Property
                    </div>

                    <div class="fw-semibold">

                        @if ($item->property)

                            {{ $item->property->name }}

                            @if ($item->property->property_code)
                                <small class="text-muted">
                                    ({{ $item->property->property_code }})
                                </small>
                            @endif

                        @elseif ($item->property_id)

                            Property #{{ $item->property_id }}

                        @else

                            -

                        @endif

                    </div>

                </div>


                {{-- Status --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Status
                    </div>

                    <div class="fw-semibold">
                        {{ ucfirst($item->status ?? '-') }}
                    </div>

                </div>


                {{-- Notes --}}
                <div class="col-md-12">

                    <div class="text-muted small">
                        Notes
                    </div>

                    <div>
                        {{ $item->notes ?? 'No notes available.' }}
                    </div>

                </div>

            </div>

        </div>

    </div>


    {{-- Sidebar --}}
    <div class="col-lg-4">

        {{-- Quick Actions --}}
        <div class="card p-4">

            <h5 class="mb-3">
                Quick Actions
            </h5>

            <div class="d-grid gap-2">

                <a
                    href="{{ route('admin.leads.edit', ['lead' => $item->id]) }}"
                    class="btn btn-outline-primary"
                >
                    Edit Lead
                </a>


                @if ($item->phone)

                    <a
                        href="tel:{{ $item->phone }}"
                        class="btn btn-outline-success"
                    >
                        Call Lead
                    </a>

                @endif


                @if ($item->email)

                    <a
                        href="mailto:{{ $item->email }}"
                        class="btn btn-outline-info"
                    >
                        Email Lead
                    </a>

                @endif


                <form
                    method="POST"
                    action="{{ route('admin.leads.destroy', ['lead' => $item->id]) }}"
                    onsubmit="return confirm('Are you sure you want to delete this lead?')"
                >

                    @csrf

                    @method('DELETE')

                    <button
                        type="submit"
                        class="btn btn-outline-danger w-100"
                    >
                        Delete Lead
                    </button>

                </form>

            </div>

        </div>


        {{-- Record Information --}}
        <div class="card p-4 mt-4">

            <h5 class="mb-3">
                Record Information
            </h5>


            <div class="mb-3">

                <div class="text-muted small">
                    Lead ID
                </div>

                <strong>
                    #{{ $item->id }}
                </strong>

            </div>


            <div class="mb-3">

                <div class="text-muted small">
                    Created
                </div>

                <strong>
                    {{ $item->created_at?->format('d M Y, h:i A') ?? '-' }}
                </strong>

            </div>


            <div>

                <div class="text-muted small">
                    Last Updated
                </div>

                <strong>
                    {{ $item->updated_at?->format('d M Y, h:i A') ?? '-' }}
                </strong>

            </div>

        </div>

    </div>

</div>

@endsection