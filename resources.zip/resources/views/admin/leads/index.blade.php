@extends('layouts.admin.app')

@section('title', 'Leads')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">

    <div>

        <h1 class="page-title mb-1">
            Leads
        </h1>

        <div class="text-muted">
            Manage property sales and customer leads
        </div>

    </div>


    <a
        href="{{ route('admin.leads.create') }}"
        class="btn btn-primary"
    >
        + Add Lead
    </a>

</div>


<div class="card p-4">

    <div class="table-responsive">

        <table class="table table-hover align-middle">

            <thead>

                <tr>

                    <th width="70">
                        ID
                    </th>

                    <th>
                        Lead
                    </th>

                    <th>
                        Contact
                    </th>

                    <th>
                        Source
                    </th>

                    <th>
                        Property
                    </th>

                    <th>
                        Status
                    </th>

                    <th>
                        Created
                    </th>

                    <th width="250">
                        Actions
                    </th>

                </tr>

            </thead>


            <tbody>

                @forelse ($items as $item)

                    <tr>

                        <td>
                            {{ $item->id }}
                        </td>


                        <td>

                            <strong>
                                {{ $item->name ?? 'Record' }}
                            </strong>

                        </td>


                        <td>

                            <div>
                                {{ $item->email ?? '-' }}
                            </div>

                            <small class="text-muted">
                                {{ $item->phone ?? '-' }}
                            </small>

                        </td>


                        <td>
                            {{ $item->source ?? '-' }}
                        </td>


                        <td>

                            @if ($item->property_id)

                                {{ $item->property?->name ?? '#' . $item->property_id }}

                            @else

                                -

                            @endif

                        </td>


                        <td>

                            @switch($item->status)

                                @case('new')

                                    <span class="badge bg-primary">
                                        New
                                    </span>

                                    @break

                                @case('contacted')

                                    <span class="badge bg-info text-dark">
                                        Contacted
                                    </span>

                                    @break

                                @case('qualified')

                                    <span class="badge bg-warning text-dark">
                                        Qualified
                                    </span>

                                    @break

                                @case('converted')

                                    <span class="badge bg-success">
                                        Converted
                                    </span>

                                    @break

                                @case('lost')

                                    <span class="badge bg-danger">
                                        Lost
                                    </span>

                                    @break

                                @default

                                    <span class="badge bg-secondary">
                                        {{ ucfirst($item->status ?? 'Unknown') }}
                                    </span>

                            @endswitch

                        </td>


                        <td>
                            {{ $item->created_at?->format('d M Y') ?? '-' }}
                        </td>


                        <td>

                            <a
                                href="{{ route('admin.leads.show', ['lead' => $item->id]) }}"
                                class="btn btn-sm btn-outline-primary"
                            >
                                View
                            </a>


                            <a
                                href="{{ route('admin.leads.edit', ['lead' => $item->id]) }}"
                                class="btn btn-sm btn-outline-secondary"
                            >
                                Edit
                            </a>


                            <form
                                action="{{ route('admin.leads.destroy', ['lead' => $item->id]) }}"
                                method="POST"
                                class="d-inline"
                                onsubmit="return confirm('Are you sure you want to delete this lead?')"
                            >

                                @csrf

                                @method('DELETE')

                                <button
                                    type="submit"
                                    class="btn btn-sm btn-outline-danger"
                                >
                                    Delete
                                </button>

                            </form>

                        </td>

                    </tr>

                @empty

                    <tr>

                        <td
                            colspan="8"
                            class="text-center py-5"
                        >

                            <div class="text-muted mb-3">
                                No leads found.
                            </div>

                            <a
                                href="{{ route('admin.leads.create') }}"
                                class="btn btn-primary btn-sm"
                            >
                                + Add Lead
                            </a>

                        </td>

                    </tr>

                @endforelse

            </tbody>

        </table>

    </div>


    <div class="mt-3">

        {{ $items->links() }}

    </div>

</div>

@endsection