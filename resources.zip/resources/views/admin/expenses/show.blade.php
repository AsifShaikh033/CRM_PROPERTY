@extends('layouts.admin.app')

@section('title', 'Expense Details')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">

    <div>

        <h1 class="page-title mb-1">
            Expense Details
        </h1>

        <div class="text-muted">
            View property expense information
        </div>

    </div>

    <div>

        <a
            href="{{ route('admin.expenses.edit', ['expense' => $item->id]) }}"
            class="btn btn-primary"
        >
            Edit Expense
        </a>

        <a
            href="{{ route('admin.expenses.index') }}"
            class="btn btn-light ms-2"
        >
            ← Back
        </a>

    </div>

</div>


<div class="row g-4">

    <div class="col-lg-8">

        <div class="card p-4">

            <div class="d-flex justify-content-between mb-4">

                <div>

                    <h4>
                        {{ $item->title }}
                    </h4>

                    <div class="text-muted">
                        Expense #{{ $item->id }}
                    </div>

                </div>


                @if($item->status === 'paid')

                    <span class="badge bg-success h-100">
                        Paid
                    </span>

                @elseif($item->status === 'pending')

                    <span class="badge bg-warning text-dark h-100">
                        Pending
                    </span>

                @elseif($item->status === 'cancelled')

                    <span class="badge bg-danger h-100">
                        Cancelled
                    </span>

                @endif

            </div>


            <div class="row g-4">

                <div class="col-md-6">

                    <div class="text-muted small">
                        Amount
                    </div>

                    <div class="fw-bold fs-3">
                        ₹{{ number_format($item->amount, 2) }}
                    </div>

                </div>


                <div class="col-md-6">

                    <div class="text-muted small">
                        Expense Date
                    </div>

                    <div class="fw-semibold">

                        {{ $item->expense_date
                            ? \Carbon\Carbon::parse($item->expense_date)->format('d M Y')
                            : '-'
                        }}

                    </div>

                </div>


                <div class="col-md-12">

                    <div class="text-muted small">
                        Property
                    </div>

                    <div class="fw-semibold">

                        {{ $item->property?->name ?? '-' }}

                    </div>

                </div>


                <div class="col-md-12">

                    <div class="text-muted small">
                        Description
                    </div>

                    <div class="mt-1">

                        {{ $item->description ?: 'No description available.' }}

                    </div>

                </div>

            </div>

        </div>

    </div>


    <div class="col-lg-4">

        <div class="card p-4">

            <h5 class="mb-3">
                Quick Actions
            </h5>

            <div class="d-grid gap-2">

                <a
                    href="{{ route('admin.expenses.edit', ['expense' => $item->id]) }}"
                    class="btn btn-outline-primary"
                >
                    Edit Expense
                </a>

                <form
                    method="POST"
                    action="{{ route('admin.expenses.destroy', ['expense' => $item->id]) }}"
                    onsubmit="return confirm('Are you sure you want to delete this expense?')"
                >

                    @csrf
                    @method('DELETE')

                    <button
                        type="submit"
                        class="btn btn-outline-danger w-100"
                    >
                        Delete Expense
                    </button>

                </form>

            </div>

        </div>


        <div class="card p-4 mt-4">

            <h5 class="mb-3">
                Record Information
            </h5>

            <div class="mb-3">

                <div class="text-muted small">
                    Expense ID
                </div>

                <strong>
                    #{{ $item->id }}
                </strong>

            </div>

            <div class="mb-3">

                <div class="text-muted small">
                    Created
                </div>

                <strong>
                    {{ $item->created_at?->format('d M Y, h:i A') ?? '-' }}
                </strong>

            </div>

            <div>

                <div class="text-muted small">
                    Last Updated
                </div>

                <strong>
                    {{ $item->updated_at?->format('d M Y, h:i A') ?? '-' }}
                </strong>

            </div>

        </div>

    </div>

</div>

@endsection