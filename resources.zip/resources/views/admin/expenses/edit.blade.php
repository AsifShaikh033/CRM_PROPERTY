@extends('layouts.admin.app')

@section('title', 'Edit Expense')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">

    <div>

        <h1 class="page-title mb-1">
            Edit Expense
        </h1>

        <div class="text-muted">
            Update expense information
        </div>

    </div>

    <div>

        <a
            href="{{ route('admin.expenses.show', ['expense' => $item->id]) }}"
            class="btn btn-outline-primary"
        >
            View Expense
        </a>

        <a
            href="{{ route('admin.expenses.index') }}"
            class="btn btn-light ms-2"
        >
            ← Back
        </a>

    </div>

</div>


<form
    method="POST"
    action="{{ route('admin.expenses.update', ['expense' => $item->id]) }}"
>

    @csrf
    @method('PUT')

    <div class="card p-4">

        <div class="row g-3">

            <div class="col-md-8">

                <label class="form-label">
                    Expense Title
                    <span class="text-danger">*</span>
                </label>

                <input
                    type="text"
                    name="title"
                    value="{{ old('title', $item->title) }}"
                    class="form-control @error('title') is-invalid @enderror"
                    required
                >

                @error('title')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            <div class="col-md-4">

                <label class="form-label">
                    Property
                </label>

                <select
                    name="property_id"
                    class="form-select"
                >

                    <option value="">
                        Select Property
                    </option>

                    @foreach($properties ?? [] as $property)

                        <option
                            value="{{ $property->id }}"
                            {{ old('property_id', $item->property_id) == $property->id ? 'selected' : '' }}
                        >
                            {{ $property->name }}

                            @if($property->property_code)
                                ({{ $property->property_code }})
                            @endif

                        </option>

                    @endforeach

                </select>

            </div>


            <div class="col-md-4">

                <label class="form-label">
                    Amount
                    <span class="text-danger">*</span>
                </label>

                <div class="input-group">

                    <span class="input-group-text">
                        ₹
                    </span>

                    <input
                        type="number"
                        name="amount"
                        value="{{ old('amount', $item->amount) }}"
                        min="0"
                        step="0.01"
                        class="form-control"
                        required
                    >

                </div>

            </div>


            <div class="col-md-4">

                <label class="form-label">
                    Expense Date
                    <span class="text-danger">*</span>
                </label>

                <input
                    type="date"
                    name="expense_date"
                    value="{{ old('expense_date', $item->expense_date ? \Carbon\Carbon::parse($item->expense_date)->format('Y-m-d') : '') }}"
                    class="form-control"
                    required
                >

            </div>


            <div class="col-md-4">

                <label class="form-label">
                    Status
                    <span class="text-danger">*</span>
                </label>

                <select
                    name="status"
                    class="form-select"
                    required
                >

                    <option
                        value="pending"
                        {{ old('status', $item->status) == 'pending' ? 'selected' : '' }}
                    >
                        Pending
                    </option>

                    <option
                        value="paid"
                        {{ old('status', $item->status) == 'paid' ? 'selected' : '' }}
                    >
                        Paid
                    </option>

                    <option
                        value="cancelled"
                        {{ old('status', $item->status) == 'cancelled' ? 'selected' : '' }}
                    >
                        Cancelled
                    </option>

                </select>

            </div>


            <div class="col-md-12">

                <label class="form-label">
                    Description
                </label>

                <textarea
                    name="description"
                    rows="5"
                    class="form-control"
                >{{ old('description', $item->description) }}</textarea>

            </div>

        </div>


        <div class="mt-4 pt-3 border-top">

            <button
                type="submit"
                class="btn btn-primary"
            >
                Update Expense
            </button>

            <a
                href="{{ route('admin.expenses.index') }}"
                class="btn btn-light ms-2"
            >
                Cancel
            </a>

        </div>

    </div>

</form>

@endsection