@extends('layouts.admin.app')

@section('title', 'Add Expense')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">

    <div>
        <h1 class="page-title mb-1">
            Add Expense
        </h1>

        <div class="text-muted">
            Record a new property expense
        </div>
    </div>

    <a
        href="{{ route('admin.expenses.index') }}"
        class="btn btn-light"
    >
        ← Back
    </a>

</div>


<form
    method="POST"
    action="{{ route('admin.expenses.store') }}"
>

    @csrf

    <div class="card p-4">

        <div class="row g-3">

            {{-- Expense Title --}}
            <div class="col-md-8">

                <label class="form-label">
                    Expense Title
                    <span class="text-danger">*</span>
                </label>

                <input
                    type="text"
                    name="title"
                    value="{{ old('title') }}"
                    class="form-control @error('title') is-invalid @enderror"
                    placeholder="e.g. Plumbing Repair, Electricity Bill"
                    required
                >

                @error('title')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Property --}}
            <div class="col-md-4">

                <label class="form-label">
                    Property
                </label>

                <select
                    name="property_id"
                    class="form-select @error('property_id') is-invalid @enderror"
                >

                    <option value="">
                        Select Property
                    </option>

                    @foreach ($properties ?? [] as $property)

                        <option
                            value="{{ $property->id }}"
                            {{ old('property_id') == $property->id ? 'selected' : '' }}
                        >
                            {{ $property->name }}

                            @if ($property->property_code)
                                ({{ $property->property_code }})
                            @endif

                        </option>

                    @endforeach

                </select>

                @error('property_id')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Amount --}}
            <div class="col-md-4">

                <label class="form-label">
                    Amount
                    <span class="text-danger">*</span>
                </label>

                <div class="input-group">

                    <span class="input-group-text">
                        ₹
                    </span>

                    <input
                        type="number"
                        name="amount"
                        value="{{ old('amount', 0) }}"
                        min="0"
                        step="0.01"
                        class="form-control @error('amount') is-invalid @enderror"
                        placeholder="0.00"
                        required
                    >

                </div>

                @error('amount')
                    <div class="text-danger small mt-1">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Expense Date --}}
            <div class="col-md-4">

                <label class="form-label">
                    Expense Date
                    <span class="text-danger">*</span>
                </label>

                <input
                    type="date"
                    name="expense_date"
                    value="{{ old('expense_date', now()->format('Y-m-d')) }}"
                    class="form-control @error('expense_date') is-invalid @enderror"
                    required
                >

                @error('expense_date')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Status --}}
            <div class="col-md-4">

                <label class="form-label">
                    Status
                    <span class="text-danger">*</span>
                </label>

                <select
                    name="status"
                    class="form-select @error('status') is-invalid @enderror"
                    required
                >

                    <option
                        value="pending"
                        {{ old('status', 'pending') == 'pending' ? 'selected' : '' }}
                    >
                        Pending
                    </option>

                    <option
                        value="paid"
                        {{ old('status') == 'paid' ? 'selected' : '' }}
                    >
                        Paid
                    </option>

                    <option
                        value="cancelled"
                        {{ old('status') == 'cancelled' ? 'selected' : '' }}
                    >
                        Cancelled
                    </option>

                </select>

                @error('status')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Description --}}
            <div class="col-md-12">

                <label class="form-label">
                    Description
                </label>

                <textarea
                    name="description"
                    rows="5"
                    class="form-control @error('description') is-invalid @enderror"
                    placeholder="Enter expense details..."
                >{{ old('description') }}</textarea>

                @error('description')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>

        </div>


        <div class="mt-4 pt-3 border-top">

            <button
                type="submit"
                class="btn btn-primary"
            >
                Save Expense
            </button>

            <a
                href="{{ route('admin.expenses.index') }}"
                class="btn btn-light ms-2"
            >
                Cancel
            </a>

        </div>

    </div>

</form>

@endsection