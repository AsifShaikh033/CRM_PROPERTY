@extends('layouts.admin.app')

@section('title', 'Expenses')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">

    <div>
        <h1 class="page-title mb-1">
            Expenses
        </h1>

        <div class="text-muted">
            Manage property expenses and costs
        </div>
    </div>

    <a
        href="{{ route('admin.expenses.create') }}"
        class="btn btn-primary"
    >
        + Add Expense
    </a>

</div>


<div class="card p-4">

    <div class="table-responsive">

        <table class="table table-hover align-middle">

            <thead>
                <tr>
                    <th>ID</th>
                    <th>Expense</th>
                    <th>Property</th>
                    <th>Expense Date</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th width="260">Actions</th>
                </tr>
            </thead>

            <tbody>

                @forelse($items as $item)

                    <tr>

                        {{-- ID --}}
                        <td>
                            #{{ $item->id }}
                        </td>


                        {{-- Expense --}}
                        <td>

                            <div class="fw-semibold">
                                {{ $item->title }}
                            </div>

                            @if($item->description)

                                <div class="text-muted small">
                                    {{ \Illuminate\Support\Str::limit($item->description, 60) }}
                                </div>

                            @endif

                        </td>


                        {{-- Property --}}
                        <td>

                            @if($item->property)

                                <div class="fw-semibold">
                                    {{ $item->property->name }}
                                </div>

                                @if($item->property->property_code)

                                    <div class="text-muted small">
                                        {{ $item->property->property_code }}
                                    </div>

                                @endif

                            @elseif($item->property_id)

                                Property #{{ $item->property_id }}

                            @else

                                <span class="text-muted">
                                    All / General
                                </span>

                            @endif

                        </td>


                        {{-- Date --}}
                        <td>

                            {{ $item->expense_date
                                ? \Carbon\Carbon::parse($item->expense_date)->format('d M Y')
                                : '-'
                            }}

                        </td>


                        {{-- Amount --}}
                        <td>

                            <strong>
                                ₹{{ number_format($item->amount ?? 0, 2) }}
                            </strong>

                        </td>


                        {{-- Status --}}
                        <td>

                            @switch($item->status)

                                @case('paid')

                                    <span class="badge bg-success">
                                        Paid
                                    </span>

                                    @break

                                @case('pending')

                                    <span class="badge bg-warning text-dark">
                                        Pending
                                    </span>

                                    @break

                                @case('cancelled')

                                    <span class="badge bg-danger">
                                        Cancelled
                                    </span>

                                    @break

                                @default

                                    <span class="badge bg-secondary">
                                        {{ ucfirst($item->status ?? 'Unknown') }}
                                    </span>

                            @endswitch

                        </td>


                        {{-- Actions --}}
                        <td>

                            <a
                                href="{{ route('admin.expenses.show', ['expense' => $item->id]) }}"
                                class="btn btn-sm btn-outline-primary"
                            >
                                View
                            </a>

                            <a
                                href="{{ route('admin.expenses.edit', ['expense' => $item->id]) }}"
                                class="btn btn-sm btn-outline-secondary"
                            >
                                Edit
                            </a>

                            <form
                                action="{{ route('admin.expenses.destroy', ['expense' => $item->id]) }}"
                                method="POST"
                                class="d-inline"
                                onsubmit="return confirm('Are you sure you want to delete this expense?')"
                            >

                                @csrf

                                @method('DELETE')

                                <button
                                    type="submit"
                                    class="btn btn-sm btn-outline-danger"
                                >
                                    Delete
                                </button>

                            </form>

                        </td>

                    </tr>

                @empty

                    <tr>

                        <td
                            colspan="7"
                            class="text-center py-5"
                        >

                            <div class="text-muted mb-3">
                                No expenses found.
                            </div>

                            <a
                                href="{{ route('admin.expenses.create') }}"
                                class="btn btn-primary btn-sm"
                            >
                                + Add Expense
                            </a>

                        </td>

                    </tr>

                @endforelse

            </tbody>

        </table>

    </div>


    {{-- Pagination --}}
    @if($items->hasPages())

        <div class="mt-3">

            {{ $items->links() }}

        </div>

    @endif

</div>

@endsection