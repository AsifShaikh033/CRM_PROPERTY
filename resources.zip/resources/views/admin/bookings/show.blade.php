@extends('layouts.admin.app')

@section('title', 'Booking Details')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">

    <div>
        <h1 class="page-title mb-1">
            Booking Details
        </h1>

        <div class="text-muted">
            View booking information
        </div>
    </div>

    <div>

        <a
            href="{{ route('admin.bookings.edit', ['booking' => $item->id]) }}"
            class="btn btn-primary"
        >
            Edit Booking
        </a>

        <a
            href="{{ route('admin.bookings.index') }}"
            class="btn btn-light ms-2"
        >
            ← Back
        </a>

    </div>

</div>


<div class="row g-4">

    {{-- Booking Information --}}
    <div class="col-lg-8">

        <div class="card p-4">

            <div class="d-flex justify-content-between align-items-center mb-4">

                <div>

                    <h4 class="mb-1">
                        Booking #{{ $item->id }}
                    </h4>

                    <div class="text-muted">
                        Property booking details
                    </div>

                </div>


                {{-- Status --}}
                @switch($item->status)

                    @case('pending')

                        <span class="badge bg-warning text-dark">
                            Pending
                        </span>

                        @break

                    @case('confirmed')

                        <span class="badge bg-success">
                            Confirmed
                        </span>

                        @break

                    @case('cancelled')

                        <span class="badge bg-danger">
                            Cancelled
                        </span>

                        @break

                    @case('completed')

                        <span class="badge bg-primary">
                            Completed
                        </span>

                        @break

                    @default

                        <span class="badge bg-secondary">
                            {{ ucfirst($item->status ?? 'Unknown') }}
                        </span>

                @endswitch

            </div>


            <div class="row g-4">

                {{-- Property --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Property
                    </div>

                    <div class="fw-semibold">

                        @if ($item->property)

                            {{ $item->property->name }}

                            @if ($item->property->property_code)

                                <small class="text-muted">
                                    ({{ $item->property->property_code }})
                                </small>

                            @endif

                        @elseif ($item->property_id)

                            Property #{{ $item->property_id }}

                        @else

                            -

                        @endif

                    </div>

                </div>


                {{-- Tenant --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Tenant / Customer
                    </div>

                    <div class="fw-semibold">

                        @if ($item->tenant)

                            {{ $item->tenant->name }}

                        @elseif ($item->tenant_id)

                            Tenant #{{ $item->tenant_id }}

                        @else

                            -

                        @endif

                    </div>

                </div>


                {{-- Tenant Phone --}}
                @if ($item->tenant?->phone)

                    <div class="col-md-6">

                        <div class="text-muted small">
                            Tenant Phone
                        </div>

                        <div class="fw-semibold">
                            {{ $item->tenant->phone }}
                        </div>

                    </div>

                @endif


                {{-- Tenant Email --}}
                @if ($item->tenant?->email)

                    <div class="col-md-6">

                        <div class="text-muted small">
                            Tenant Email
                        </div>

                        <div class="fw-semibold">
                            {{ $item->tenant->email }}
                        </div>

                    </div>

                @endif


                {{-- Booking Date --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Booking Date & Time
                    </div>

                    <div class="fw-semibold">

                        {{ $item->booking_date
                            ? \Carbon\Carbon::parse($item->booking_date)->format('d M Y, h:i A')
                            : '-'
                        }}

                    </div>

                </div>


                {{-- Amount --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Booking Amount
                    </div>

                    <div class="fw-semibold fs-5">
                        ₹{{ number_format($item->amount ?? 0, 2) }}
                    </div>

                </div>


                {{-- Status --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Status
                    </div>

                    <div>
                        {{ ucfirst($item->status ?? '-') }}
                    </div>

                </div>


                {{-- Notes --}}
                <div class="col-md-12">

                    <div class="text-muted small">
                        Notes
                    </div>

                    <div>
                        {{ $item->notes ?? 'No notes available.' }}
                    </div>

                </div>

            </div>

        </div>

    </div>


    {{-- Sidebar --}}
    <div class="col-lg-4">


        {{-- Quick Actions --}}
        <div class="card p-4">

            <h5 class="mb-3">
                Quick Actions
            </h5>


            <div class="d-grid gap-2">

                <a
                    href="{{ route('admin.bookings.edit', ['booking' => $item->id]) }}"
                    class="btn btn-outline-primary"
                >
                    Edit Booking
                </a>


                @if ($item->tenant?->phone)

                    <a
                        href="tel:{{ $item->tenant->phone }}"
                        class="btn btn-outline-success"
                    >
                        Call Tenant
                    </a>

                @endif


                @if ($item->tenant?->email)

                    <a
                        href="mailto:{{ $item->tenant->email }}"
                        class="btn btn-outline-info"
                    >
                        Email Tenant
                    </a>

                @endif


                <form
                    method="POST"
                    action="{{ route('admin.bookings.destroy', ['booking' => $item->id]) }}"
                    onsubmit="return confirm('Are you sure you want to delete this booking?')"
                >

                    @csrf

                    @method('DELETE')

                    <button
                        type="submit"
                        class="btn btn-outline-danger w-100"
                    >
                        Delete Booking
                    </button>

                </form>

            </div>

        </div>


        {{-- Record Information --}}
        <div class="card p-4 mt-4">

            <h5 class="mb-3">
                Record Information
            </h5>


            <div class="mb-3">

                <div class="text-muted small">
                    Booking ID
                </div>

                <strong>
                    #{{ $item->id }}
                </strong>

            </div>


            <div class="mb-3">

                <div class="text-muted small">
                    Created
                </div>

                <strong>
                    {{ $item->created_at?->format('d M Y, h:i A') ?? '-' }}
                </strong>

            </div>


            <div>

                <div class="text-muted small">
                    Last Updated
                </div>

                <strong>
                    {{ $item->updated_at?->format('d M Y, h:i A') ?? '-' }}
                </strong>

            </div>

        </div>

    </div>

</div>

@endsection