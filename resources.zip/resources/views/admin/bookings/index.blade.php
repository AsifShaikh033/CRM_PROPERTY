@extends('layouts.admin.app')

@section('title', 'Bookings')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">

    <div>
        <h1 class="page-title mb-1">
            Bookings
        </h1>

        <div class="text-muted">
            Manage property bookings and reservations
        </div>
    </div>

    <a
        href="{{ route('admin.bookings.create') }}"
        class="btn btn-primary"
    >
        + Add Booking
    </a>

</div>


<div class="card p-4">

    <div class="table-responsive">

        <table class="table table-hover align-middle">

            <thead>

                <tr>

                    <th width="70">
                        ID
                    </th>

                    <th>
                        Property
                    </th>

                    <th>
                        Tenant
                    </th>

                    <th>
                        Booking Date
                    </th>

                    <th>
                        Amount
                    </th>

                    <th>
                        Status
                    </th>

                    <th>
                        Created
                    </th>

                    <th width="250">
                        Actions
                    </th>

                </tr>

            </thead>


            <tbody>

                @forelse ($items as $item)

                    <tr>

                        <td>
                            {{ $item->id }}
                        </td>


                        <td>

                            @if ($item->property)

                                <strong>
                                    {{ $item->property->name }}
                                </strong>

                                @if ($item->property->property_code)

                                    <div class="small text-muted">
                                        {{ $item->property->property_code }}
                                    </div>

                                @endif

                            @elseif ($item->property_id)

                                Property #{{ $item->property_id }}

                            @else

                                -

                            @endif

                        </td>


                        <td>

                            @if ($item->tenant)

                                <strong>
                                    {{ $item->tenant->name }}
                                </strong>

                                @if ($item->tenant->phone)

                                    <div class="small text-muted">
                                        {{ $item->tenant->phone }}
                                    </div>

                                @endif

                            @elseif ($item->tenant_id)

                                Tenant #{{ $item->tenant_id }}

                            @else

                                -

                            @endif

                        </td>


                        <td>

                            {{ $item->booking_date
                                ? \Carbon\Carbon::parse($item->booking_date)->format('d M Y, h:i A')
                                : '-'
                            }}

                        </td>


                        <td>

                            ₹{{ number_format($item->amount ?? 0, 2) }}

                        </td>


                        <td>

                            @switch($item->status)

                                @case('pending')

                                    <span class="badge bg-warning text-dark">
                                        Pending
                                    </span>

                                    @break

                                @case('confirmed')

                                    <span class="badge bg-success">
                                        Confirmed
                                    </span>

                                    @break

                                @case('cancelled')

                                    <span class="badge bg-danger">
                                        Cancelled
                                    </span>

                                    @break

                                @case('completed')

                                    <span class="badge bg-primary">
                                        Completed
                                    </span>

                                    @break

                                @default

                                    <span class="badge bg-secondary">
                                        {{ ucfirst($item->status ?? 'Unknown') }}
                                    </span>

                            @endswitch

                        </td>


                        <td>
                            {{ $item->created_at?->format('d M Y') ?? '-' }}
                        </td>


                        <td>

                            <a
                                href="{{ route('admin.bookings.show', ['booking' => $item->id]) }}"
                                class="btn btn-sm btn-outline-primary"
                            >
                                View
                            </a>


                            <a
                                href="{{ route('admin.bookings.edit', ['booking' => $item->id]) }}"
                                class="btn btn-sm btn-outline-secondary"
                            >
                                Edit
                            </a>


                            <form
                                action="{{ route('admin.bookings.destroy', ['booking' => $item->id]) }}"
                                method="POST"
                                class="d-inline"
                                onsubmit="return confirm('Are you sure you want to delete this booking?')"
                            >

                                @csrf

                                @method('DELETE')

                                <button
                                    type="submit"
                                    class="btn btn-sm btn-outline-danger"
                                >
                                    Delete
                                </button>

                            </form>

                        </td>

                    </tr>

                @empty

                    <tr>

                        <td
                            colspan="8"
                            class="text-center py-5"
                        >

                            <div class="text-muted mb-3">
                                No bookings found.
                            </div>

                            <a
                                href="{{ route('admin.bookings.create') }}"
                                class="btn btn-primary btn-sm"
                            >
                                + Add Booking
                            </a>

                        </td>

                    </tr>

                @endforelse

            </tbody>

        </table>

    </div>


    <div class="mt-3">

        {{ $items->links() }}

    </div>

</div>

@endsection