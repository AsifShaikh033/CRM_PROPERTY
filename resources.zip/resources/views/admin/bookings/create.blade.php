@extends('layouts.admin.app')

@section('title', 'Add Booking')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">

    <div>
        <h1 class="page-title mb-1">
            Add Booking
        </h1>

        <div class="text-muted">
            Create a new property booking
        </div>
    </div>

    <a
        href="{{ route('admin.bookings.index') }}"
        class="btn btn-light"
    >
        ← Back
    </a>

</div>


<form
    method="POST"
    action="{{ route('admin.bookings.store') }}"
>

    @csrf

    <div class="card p-4">

        <div class="row g-3">

            {{-- Property --}}
            <div class="col-md-6">

                <label class="form-label">
                    Property
                </label>

                <select
                    name="property_id"
                    class="form-select @error('property_id') is-invalid @enderror"
                >

                    <option value="">
                        Select Property
                    </option>

                    @foreach ($properties ?? [] as $property)

                        <option
                            value="{{ $property->id }}"
                            {{ old('property_id') == $property->id ? 'selected' : '' }}
                        >
                            {{ $property->name }}

                            @if ($property->property_code)
                                ({{ $property->property_code }})
                            @endif

                        </option>

                    @endforeach

                </select>

                @error('property_id')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Tenant --}}
            <div class="col-md-6">

                <label class="form-label">
                    Tenant / Customer
                </label>

                <select
                    name="tenant_id"
                    class="form-select @error('tenant_id') is-invalid @enderror"
                >

                    <option value="">
                        Select Tenant
                    </option>

                    @foreach ($tenants ?? [] as $tenant)

                        <option
                            value="{{ $tenant->id }}"
                            {{ old('tenant_id') == $tenant->id ? 'selected' : '' }}
                        >
                            {{ $tenant->name }}

                            @if ($tenant->phone)
                                - {{ $tenant->phone }}
                            @endif

                        </option>

                    @endforeach

                </select>

                @error('tenant_id')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Booking Date --}}
            <div class="col-md-6">

                <label class="form-label">
                    Booking Date & Time
                    <span class="text-danger">*</span>
                </label>

                <input
                    type="datetime-local"
                    name="booking_date"
                    value="{{ old('booking_date') }}"
                    class="form-control @error('booking_date') is-invalid @enderror"
                    required
                >

                @error('booking_date')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Amount --}}
            <div class="col-md-3">

                <label class="form-label">
                    Booking Amount
                    <span class="text-danger">*</span>
                </label>

                <div class="input-group">

                    <span class="input-group-text">
                        ₹
                    </span>

                    <input
                        type="number"
                        name="amount"
                        value="{{ old('amount', 0) }}"
                        min="0"
                        step="0.01"
                        class="form-control @error('amount') is-invalid @enderror"
                        placeholder="0.00"
                        required
                    >

                </div>

                @error('amount')
                    <div class="text-danger small mt-1">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Status --}}
            <div class="col-md-3">

                <label class="form-label">
                    Status
                    <span class="text-danger">*</span>
                </label>

                <select
                    name="status"
                    class="form-select @error('status') is-invalid @enderror"
                    required
                >

                    <option
                        value="pending"
                        {{ old('status', 'pending') === 'pending' ? 'selected' : '' }}
                    >
                        Pending
                    </option>

                    <option
                        value="confirmed"
                        {{ old('status') === 'confirmed' ? 'selected' : '' }}
                    >
                        Confirmed
                    </option>

                    <option
                        value="cancelled"
                        {{ old('status') === 'cancelled' ? 'selected' : '' }}
                    >
                        Cancelled
                    </option>

                    <option
                        value="completed"
                        {{ old('status') === 'completed' ? 'selected' : '' }}
                    >
                        Completed
                    </option>

                </select>

                @error('status')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Notes --}}
            <div class="col-md-12">

                <label class="form-label">
                    Notes
                </label>

                <textarea
                    name="notes"
                    rows="5"
                    class="form-control @error('notes') is-invalid @enderror"
                    placeholder="Add booking notes"
                >{{ old('notes') }}</textarea>

                @error('notes')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>

        </div>


        {{-- Buttons --}}
        <div class="mt-4 pt-3 border-top">

            <button
                type="submit"
                class="btn btn-primary"
            >
                Save Booking
            </button>

            <a
                href="{{ route('admin.bookings.index') }}"
                class="btn btn-light ms-2"
            >
                Cancel
            </a>

        </div>

    </div>

</form>

@endsection