@extends('layouts.admin.app')

@section('title', 'Add Property Visit')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">

    <div>
        <h1 class="page-title mb-1">
            Add Property Visit
        </h1>

        <div class="text-muted">
            Schedule a property visit
        </div>
    </div>

    <a
        href="{{ route('admin.visits.index') }}"
        class="btn btn-light"
    >
        ← Back
    </a>

</div>


<form
    method="POST"
    action="{{ route('admin.visits.store') }}"
>

    @csrf

    <div class="card p-4">

        <div class="row g-3">

            {{-- Property --}}
            <div class="col-md-6">

                <label class="form-label">
                    Property
                </label>

                <select
                    name="property_id"
                    class="form-select @error('property_id') is-invalid @enderror"
                >

                    <option value="">
                        Select Property
                    </option>

                    @foreach ($properties ?? [] as $property)

                        <option
                            value="{{ $property->id }}"
                            {{ old('property_id') == $property->id ? 'selected' : '' }}
                        >
                            {{ $property->name }}

                            @if ($property->property_code)
                                ({{ $property->property_code }})
                            @endif

                        </option>

                    @endforeach

                </select>

                @error('property_id')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Lead --}}
            <div class="col-md-6">

                <label class="form-label">
                    Lead / Customer
                </label>

                <select
                    name="lead_id"
                    class="form-select @error('lead_id') is-invalid @enderror"
                >

                    <option value="">
                        Select Lead
                    </option>

                    @foreach ($leads ?? [] as $lead)

                        <option
                            value="{{ $lead->id }}"
                            {{ old('lead_id') == $lead->id ? 'selected' : '' }}
                        >
                            {{ $lead->name }}

                            @if ($lead->phone)
                                - {{ $lead->phone }}
                            @endif

                        </option>

                    @endforeach

                </select>

                @error('lead_id')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Visit Date --}}
            <div class="col-md-6">

                <label class="form-label">
                    Visit Date & Time
                    <span class="text-danger">*</span>
                </label>

                <input
                    type="datetime-local"
                    name="visit_date"
                    value="{{ old('visit_date') }}"
                    class="form-control @error('visit_date') is-invalid @enderror"
                    required
                >

                @error('visit_date')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Status --}}
            <div class="col-md-6">

                <label class="form-label">
                    Status
                    <span class="text-danger">*</span>
                </label>

                <select
                    name="status"
                    class="form-select @error('status') is-invalid @enderror"
                    required
                >

                    <option
                        value="scheduled"
                        {{ old('status', 'scheduled') === 'scheduled' ? 'selected' : '' }}
                    >
                        Scheduled
                    </option>

                    <option
                        value="completed"
                        {{ old('status') === 'completed' ? 'selected' : '' }}
                    >
                        Completed
                    </option>

                    <option
                        value="cancelled"
                        {{ old('status') === 'cancelled' ? 'selected' : '' }}
                    >
                        Cancelled
                    </option>

                </select>

                @error('status')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Notes --}}
            <div class="col-md-12">

                <label class="form-label">
                    Notes
                </label>

                <textarea
                    name="notes"
                    rows="5"
                    class="form-control @error('notes') is-invalid @enderror"
                    placeholder="Add notes about the visit"
                >{{ old('notes') }}</textarea>

                @error('notes')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>

        </div>


        {{-- Buttons --}}
        <div class="mt-4 pt-3 border-top">

            <button
                type="submit"
                class="btn btn-primary"
            >
                Save Visit
            </button>

            <a
                href="{{ route('admin.visits.index') }}"
                class="btn btn-light ms-2"
            >
                Cancel
            </a>

        </div>

    </div>

</form>

@endsection