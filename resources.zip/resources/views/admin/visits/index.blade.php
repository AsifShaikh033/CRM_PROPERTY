@extends('layouts.admin.app')

@section('title', 'Property Visits')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">

    <div>

        <h1 class="page-title mb-1">
            Property Visits
        </h1>

        <div class="text-muted">
            Manage property visits and appointments
        </div>

    </div>


    <a
        href="{{ route('admin.visits.create') }}"
        class="btn btn-primary"
    >
        + Add Visit
    </a>

</div>


<div class="card p-4">

    <div class="table-responsive">

        <table class="table table-hover align-middle">

            <thead>

                <tr>

                    <th width="70">
                        ID
                    </th>

                    <th>
                        Property
                    </th>

                    <th>
                        Lead
                    </th>

                    <th>
                        Visit Date
                    </th>

                    <th>
                        Status
                    </th>

                    <th>
                        Created
                    </th>

                    <th width="250">
                        Actions
                    </th>

                </tr>

            </thead>


            <tbody>

                @forelse ($items as $item)

                    <tr>

                        <td>
                            {{ $item->id }}
                        </td>


                        <td>

                            @if ($item->property)

                                <strong>
                                    {{ $item->property->name }}
                                </strong>

                                @if ($item->property->property_code)

                                    <div class="small text-muted">
                                        {{ $item->property->property_code }}
                                    </div>

                                @endif

                            @elseif ($item->property_id)

                                Property #{{ $item->property_id }}

                            @else

                                -

                            @endif

                        </td>


                        <td>

                            @if ($item->lead)

                                {{ $item->lead->name }}

                            @elseif ($item->lead_id)

                                Lead #{{ $item->lead_id }}

                            @else

                                -

                            @endif

                        </td>


                        <td>

                            {{ $item->visit_date
                                ? \Carbon\Carbon::parse($item->visit_date)->format('d M Y, h:i A')
                                : '-'
                            }}

                        </td>


                        <td>

                            @switch($item->status)

                                @case('scheduled')

                                    <span class="badge bg-primary">
                                        Scheduled
                                    </span>

                                    @break

                                @case('completed')

                                    <span class="badge bg-success">
                                        Completed
                                    </span>

                                    @break

                                @case('cancelled')

                                    <span class="badge bg-danger">
                                        Cancelled
                                    </span>

                                    @break

                                @default

                                    <span class="badge bg-secondary">
                                        {{ ucfirst($item->status ?? 'Unknown') }}
                                    </span>

                            @endswitch

                        </td>


                        <td>
                            {{ $item->created_at?->format('d M Y') ?? '-' }}
                        </td>


                        <td>

                            <a
                                href="{{ route('admin.visits.show', ['visit' => $item->id]) }}"
                                class="btn btn-sm btn-outline-primary"
                            >
                                View
                            </a>


                            <a
                                href="{{ route('admin.visits.edit', ['visit' => $item->id]) }}"
                                class="btn btn-sm btn-outline-secondary"
                            >
                                Edit
                            </a>


                            <form
                                action="{{ route('admin.visits.destroy', ['visit' => $item->id]) }}"
                                method="POST"
                                class="d-inline"
                                onsubmit="return confirm('Are you sure you want to delete this visit?')"
                            >

                                @csrf

                                @method('DELETE')

                                <button
                                    type="submit"
                                    class="btn btn-sm btn-outline-danger"
                                >
                                    Delete
                                </button>

                            </form>

                        </td>

                    </tr>

                @empty

                    <tr>

                        <td
                            colspan="7"
                            class="text-center py-5"
                        >

                            <div class="text-muted mb-3">
                                No property visits found.
                            </div>

                            <a
                                href="{{ route('admin.visits.create') }}"
                                class="btn btn-primary btn-sm"
                            >
                                + Add Visit
                            </a>

                        </td>

                    </tr>

                @endforelse

            </tbody>

        </table>

    </div>


    <div class="mt-3">

        {{ $items->links() }}

    </div>

</div>

@endsection