@extends('layouts.admin.app')

@section('title', 'Property Visit Details')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">

    <div>
        <h1 class="page-title mb-1">
            Property Visit Details
        </h1>

        <div class="text-muted">
            View property visit information
        </div>
    </div>

    <div>

        <a
            href="{{ route('admin.visits.edit', ['visit' => $item->id]) }}"
            class="btn btn-primary"
        >
            Edit Visit
        </a>

        <a
            href="{{ route('admin.visits.index') }}"
            class="btn btn-light ms-2"
        >
            ← Back
        </a>

    </div>

</div>


<div class="row g-4">

    {{-- Visit Information --}}
    <div class="col-lg-8">

        <div class="card p-4">

            <div class="d-flex justify-content-between align-items-center mb-4">

                <div>

                    <h4 class="mb-1">
                        Property Visit #{{ $item->id }}
                    </h4>

                    <div class="text-muted">
                        Visit appointment details
                    </div>

                </div>


                @switch($item->status)

                    @case('scheduled')

                        <span class="badge bg-primary">
                            Scheduled
                        </span>

                        @break

                    @case('completed')

                        <span class="badge bg-success">
                            Completed
                        </span>

                        @break

                    @case('cancelled')

                        <span class="badge bg-danger">
                            Cancelled
                        </span>

                        @break

                    @default

                        <span class="badge bg-secondary">
                            {{ ucfirst($item->status ?? 'Unknown') }}
                        </span>

                @endswitch

            </div>


            <div class="row g-4">

                {{-- Property --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Property
                    </div>

                    <div class="fw-semibold">

                        @if ($item->property)

                            {{ $item->property->name }}

                            @if ($item->property->property_code)

                                <small class="text-muted">
                                    ({{ $item->property->property_code }})
                                </small>

                            @endif

                        @elseif ($item->property_id)

                            Property #{{ $item->property_id }}

                        @else

                            -

                        @endif

                    </div>

                </div>


                {{-- Lead --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Lead / Customer
                    </div>

                    <div class="fw-semibold">

                        @if ($item->lead)

                            {{ $item->lead->name }}

                        @elseif ($item->lead_id)

                            Lead #{{ $item->lead_id }}

                        @else

                            -

                        @endif

                    </div>

                </div>


                {{-- Lead Phone --}}
                @if ($item->lead?->phone)

                    <div class="col-md-6">

                        <div class="text-muted small">
                            Customer Phone
                        </div>

                        <div class="fw-semibold">
                            {{ $item->lead->phone }}
                        </div>

                    </div>

                @endif


                {{-- Visit Date --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Visit Date & Time
                    </div>

                    <div class="fw-semibold">

                        {{ $item->visit_date
                            ? \Carbon\Carbon::parse($item->visit_date)->format('d M Y, h:i A')
                            : '-'
                        }}

                    </div>

                </div>


                {{-- Status --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Status
                    </div>

                    <div>

                        @switch($item->status)

                            @case('scheduled')

                                <span class="badge bg-primary">
                                    Scheduled
                                </span>

                                @break

                            @case('completed')

                                <span class="badge bg-success">
                                    Completed
                                </span>

                                @break

                            @case('cancelled')

                                <span class="badge bg-danger">
                                    Cancelled
                                </span>

                                @break

                            @default

                                <span class="badge bg-secondary">
                                    {{ ucfirst($item->status ?? 'Unknown') }}
                                </span>

                        @endswitch

                    </div>

                </div>


                {{-- Notes --}}
                <div class="col-md-12">

                    <div class="text-muted small">
                        Notes
                    </div>

                    <div>
                        {{ $item->notes ?? 'No notes available.' }}
                    </div>

                </div>

            </div>

        </div>

    </div>


    {{-- Sidebar --}}
    <div class="col-lg-4">


        {{-- Quick Actions --}}
        <div class="card p-4">

            <h5 class="mb-3">
                Quick Actions
            </h5>


            <div class="d-grid gap-2">

                <a
                    href="{{ route('admin.visits.edit', ['visit' => $item->id]) }}"
                    class="btn btn-outline-primary"
                >
                    Edit Visit
                </a>


                @if ($item->lead?->phone)

                    <a
                        href="tel:{{ $item->lead->phone }}"
                        class="btn btn-outline-success"
                    >
                        Call Customer
                    </a>

                @endif


                @if ($item->lead?->email)

                    <a
                        href="mailto:{{ $item->lead->email }}"
                        class="btn btn-outline-info"
                    >
                        Email Customer
                    </a>

                @endif


                <form
                    method="POST"
                    action="{{ route('admin.visits.destroy', ['visit' => $item->id]) }}"
                    onsubmit="return confirm('Are you sure you want to delete this visit?')"
                >

                    @csrf

                    @method('DELETE')

                    <button
                        type="submit"
                        class="btn btn-outline-danger w-100"
                    >
                        Delete Visit
                    </button>

                </form>

            </div>

        </div>


        {{-- Record Information --}}
        <div class="card p-4 mt-4">

            <h5 class="mb-3">
                Record Information
            </h5>


            <div class="mb-3">

                <div class="text-muted small">
                    Visit ID
                </div>

                <strong>
                    #{{ $item->id }}
                </strong>

            </div>


            <div class="mb-3">

                <div class="text-muted small">
                    Created
                </div>

                <strong>
                    {{ $item->created_at?->format('d M Y, h:i A') ?? '-' }}
                </strong>

            </div>


            <div>

                <div class="text-muted small">
                    Last Updated
                </div>

                <strong>
                    {{ $item->updated_at?->format('d M Y, h:i A') ?? '-' }}
                </strong>

            </div>

        </div>

    </div>

</div>

@endsection