@extends('layouts.admin.app')

@section('title', 'Rent Payments')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">

    <div>

        <h1 class="page-title mb-1">
            Rent Payments
        </h1>

        <div class="text-muted">
            Manage monthly rent payments and payment records
        </div>

    </div>

    <a
        href="{{ route('admin.rent-payments.create') }}"
        class="btn btn-primary"
    >
        + Add Payment
    </a>

</div>


<div class="card p-4">

    <div class="table-responsive">

        <table class="table table-hover align-middle">

            <thead>

                <tr>

                    <th>ID</th>

                    <th>Tenant</th>

                    <th>Property</th>

                    <th>Payment Date</th>

                    <th>Rent Period</th>

                    <th>Amount</th>

                    <th>Method</th>

                    <th>Status</th>

                    <th width="250">Actions</th>

                </tr>

            </thead>


            <tbody>

                @forelse ($items as $item)

                    <tr>

                        <td>
                            #{{ $item->id }}
                        </td>


                        {{-- Tenant --}}
                        <td>

                            @if ($item->tenant)

                                <strong>
                                    {{ $item->tenant->name }}
                                </strong>

                                @if ($item->tenant->phone)

                                    <div class="small text-muted">
                                        {{ $item->tenant->phone }}
                                    </div>

                                @endif

                            @elseif ($item->tenant_id)

                                Tenant #{{ $item->tenant_id }}

                            @else

                                -

                            @endif

                        </td>


                        {{-- Property --}}
                        <td>

                            @if ($item->property)

                                <strong>
                                    {{ $item->property->name }}
                                </strong>

                                @if ($item->property->property_code)

                                    <div class="small text-muted">
                                        {{ $item->property->property_code }}
                                    </div>

                                @endif

                            @elseif ($item->property_id)

                                Property #{{ $item->property_id }}

                            @else

                                -

                            @endif

                        </td>


                        {{-- Payment Date --}}
                        <td>

                            {{ $item->payment_date
                                ? \Carbon\Carbon::parse($item->payment_date)->format('d M Y')
                                : '-'
                            }}

                        </td>


                        {{-- Month / Year --}}
                        <td>

                            @if ($item->month || $item->year)

                                {{ $item->month ?? '' }}

                                @if ($item->month && $item->year)
                                    /
                                @endif

                                {{ $item->year ?? '' }}

                            @else

                                -

                            @endif

                        </td>


                        {{-- Amount --}}
                        <td>

                            <strong>
                                ₹{{ number_format($item->amount ?? 0, 2) }}
                            </strong>

                        </td>


                        {{-- Method --}}
                        <td>

                            {{ $item->method
                                ? ucfirst($item->method)
                                : '-'
                            }}

                        </td>


                        {{-- Status --}}
                        <td>

                            @switch($item->status)

                                @case('paid')

                                    <span class="badge bg-success">
                                        Paid
                                    </span>

                                    @break

                                @case('pending')

                                    <span class="badge bg-warning text-dark">
                                        Pending
                                    </span>

                                    @break

                                @case('failed')

                                    <span class="badge bg-danger">
                                        Failed
                                    </span>

                                    @break

                                @case('refunded')

                                    <span class="badge bg-info text-dark">
                                        Refunded
                                    </span>

                                    @break

                                @default

                                    <span class="badge bg-secondary">
                                        {{ ucfirst($item->status ?? 'Unknown') }}
                                    </span>

                            @endswitch

                        </td>


                        {{-- Actions --}}
                        <td>

                            <a
                                href="{{ route('admin.rent-payments.show', ['rent_payment' => $item->id]) }}"
                                class="btn btn-sm btn-outline-primary"
                            >
                                View
                            </a>


                            <a
                                href="{{ route('admin.rent-payments.edit', ['rent_payment' => $item->id]) }}"
                                class="btn btn-sm btn-outline-secondary"
                            >
                                Edit
                            </a>


                            <form
                                action="{{ route('admin.rent-payments.destroy', ['rent_payment' => $item->id]) }}"
                                method="POST"
                                class="d-inline"
                                onsubmit="return confirm('Are you sure you want to delete this payment?')"
                            >

                                @csrf

                                @method('DELETE')

                                <button
                                    type="submit"
                                    class="btn btn-sm btn-outline-danger"
                                >
                                    Delete
                                </button>

                            </form>

                        </td>

                    </tr>


                @empty

                    <tr>

                        <td
                            colspan="9"
                            class="text-center py-5"
                        >

                            <div class="text-muted mb-3">
                                No rent payments found.
                            </div>

                            <a
                                href="{{ route('admin.rent-payments.create') }}"
                                class="btn btn-primary btn-sm"
                            >
                                + Add Payment
                            </a>

                        </td>

                    </tr>

                @endforelse

            </tbody>

        </table>

    </div>


    <div class="mt-3">

        {{ $items->links() }}

    </div>

</div>

@endsection