@extends('layouts.admin.app')

@section('title', 'Edit Rent Payment')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">

    <div>
        <h1 class="page-title mb-1">
            Edit Rent Payment
        </h1>

        <div class="text-muted">
            Update rent payment information
        </div>
    </div>

    <div>

        <a
            href="{{ route('admin.rent-payments.show', ['rent_payment' => $item->id]) }}"
            class="btn btn-outline-primary"
        >
            View Payment
        </a>

        <a
            href="{{ route('admin.rent-payments.index') }}"
            class="btn btn-light ms-2"
        >
            ← Back
        </a>

    </div>

</div>


<form
    method="POST"
    action="{{ route('admin.rent-payments.update', ['rent_payment' => $item->id]) }}"
>

    @csrf

    @method('PUT')


    <div class="card p-4">

        <div class="row g-3">


            {{-- Tenant --}}
            <div class="col-md-6">

                <label class="form-label">
                    Tenant
                </label>

                <select
                    name="tenant_id"
                    class="form-select @error('tenant_id') is-invalid @enderror"
                >

                    <option value="">
                        Select Tenant
                    </option>

                    @foreach ($tenants ?? [] as $tenant)

                        <option
                            value="{{ $tenant->id }}"
                            {{ old('tenant_id', $item->tenant_id) == $tenant->id ? 'selected' : '' }}
                        >
                            {{ $tenant->name }}

                            @if ($tenant->phone)
                                - {{ $tenant->phone }}
                            @endif

                        </option>

                    @endforeach

                </select>

                @error('tenant_id')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Property --}}
            <div class="col-md-6">

                <label class="form-label">
                    Property
                </label>

                <select
                    name="property_id"
                    class="form-select @error('property_id') is-invalid @enderror"
                >

                    <option value="">
                        Select Property
                    </option>

                    @foreach ($properties ?? [] as $property)

                        <option
                            value="{{ $property->id }}"
                            {{ old('property_id', $item->property_id) == $property->id ? 'selected' : '' }}
                        >
                            {{ $property->name }}

                            @if ($property->property_code)
                                ({{ $property->property_code }})
                            @endif

                        </option>

                    @endforeach

                </select>

                @error('property_id')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Unit --}}
            <!-- <div class="col-md-6">

                <label class="form-label">
                    Unit
                </label>

                <select
                    name="unit_id"
                    class="form-select @error('unit_id') is-invalid @enderror"
                >

                    <option value="">
                        Select Unit
                    </option>

                    @foreach ($units ?? [] as $unit)

                        <option
                            value="{{ $unit->id }}"
                            {{ old('unit_id', $item->unit_id) == $unit->id ? 'selected' : '' }}
                        >
                            {{ $unit->name ?? $unit->unit_number ?? 'Unit #' . $unit->id }}
                        </option>

                    @endforeach

                </select>

                @error('unit_id')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div> -->


            {{-- Amount --}}
            <div class="col-md-3">

                <label class="form-label">
                    Amount
                    <span class="text-danger">*</span>
                </label>

                <div class="input-group">

                    <span class="input-group-text">
                        ₹
                    </span>

                    <input
                        type="number"
                        name="amount"
                        value="{{ old('amount', $item->amount ?? 0) }}"
                        min="0"
                        step="0.01"
                        class="form-control @error('amount') is-invalid @enderror"
                        required
                    >

                </div>

                @error('amount')
                    <div class="text-danger small mt-1">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Payment Date --}}
            <div class="col-md-3">

                <label class="form-label">
                    Payment Date
                    <span class="text-danger">*</span>
                </label>

                <input
                    type="date"
                    name="payment_date"
                    value="{{ old('payment_date', $item->payment_date ? \Carbon\Carbon::parse($item->payment_date)->format('Y-m-d') : '') }}"
                    class="form-control @error('payment_date') is-invalid @enderror"
                    required
                >

                @error('payment_date')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Month --}}
            <div class="col-md-4">

                <label class="form-label">
                    Rent Month
                </label>

                <select
                    name="month"
                    class="form-select @error('month') is-invalid @enderror"
                >

                    <option value="">
                        Select Month
                    </option>

                    @foreach ([
                        '1' => 'January',
                        '2' => 'February',
                        '3' => 'March',
                        '4' => 'April',
                        '5' => 'May',
                        '6' => 'June',
                        '7' => 'July',
                        '8' => 'August',
                        '9' => 'September',
                        '10' => 'October',
                        '11' => 'November',
                        '12' => 'December'
                    ] as $month => $monthName)

                        <option
                            value="{{ $month }}"
                            {{ old('month', $item->month) == $month ? 'selected' : '' }}
                        >
                            {{ $monthName }}
                        </option>

                    @endforeach

                </select>

                @error('month')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Year --}}
            <div class="col-md-4">

                <label class="form-label">
                    Rent Year
                </label>

                <select
                    name="year"
                    class="form-select @error('year') is-invalid @enderror"
                >

                    <option value="">
                        Select Year
                    </option>

                    @for ($year = now()->year - 2; $year <= now()->year + 2; $year++)

                        <option
                            value="{{ $year }}"
                            {{ old('year', $item->year) == $year ? 'selected' : '' }}
                        >
                            {{ $year }}
                        </option>

                    @endfor

                </select>

                @error('year')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Payment Method --}}
            <div class="col-md-4">

                <label class="form-label">
                    Payment Method
                </label>

                <select
                    name="method"
                    class="form-select @error('method') is-invalid @enderror"
                >

                    <option value="">
                        Select Method
                    </option>

                    @foreach ([
                        'cash' => 'Cash',
                        'bank_transfer' => 'Bank Transfer',
                        'upi' => 'UPI',
                        'card' => 'Card',
                        'cheque' => 'Cheque',
                        'online' => 'Online'
                    ] as $value => $label)

                        <option
                            value="{{ $value }}"
                            {{ old('method', $item->method) == $value ? 'selected' : '' }}
                        >
                            {{ $label }}
                        </option>

                    @endforeach

                </select>

                @error('method')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Status --}}
            <div class="col-md-4">

                <label class="form-label">
                    Status
                    <span class="text-danger">*</span>
                </label>

                <select
                    name="status"
                    class="form-select @error('status') is-invalid @enderror"
                    required
                >

                    <option
                        value="pending"
                        {{ old('status', $item->status) == 'pending' ? 'selected' : '' }}
                    >
                        Pending
                    </option>

                    <option
                        value="paid"
                        {{ old('status', $item->status) == 'paid' ? 'selected' : '' }}
                    >
                        Paid
                    </option>

                    <option
                        value="failed"
                        {{ old('status', $item->status) == 'failed' ? 'selected' : '' }}
                    >
                        Failed
                    </option>

                    <option
                        value="refunded"
                        {{ old('status', $item->status) == 'refunded' ? 'selected' : '' }}
                    >
                        Refunded
                    </option>

                </select>

                @error('status')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Reference --}}
            <div class="col-md-8">

                <label class="form-label">
                    Payment Reference
                </label>

                <input
                    type="text"
                    name="reference"
                    value="{{ old('reference', $item->reference) }}"
                    class="form-control @error('reference') is-invalid @enderror"
                    placeholder="Transaction ID / Receipt Number"
                >

                @error('reference')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>

        </div>


        {{-- Buttons --}}
        <div class="mt-4 pt-3 border-top">

            <button
                type="submit"
                class="btn btn-primary"
            >
                Update Rent Payment
            </button>

            <a
                href="{{ route('admin.rent-payments.index') }}"
                class="btn btn-light ms-2"
            >
                Cancel
            </a>

        </div>

    </div>

</form>

@endsection