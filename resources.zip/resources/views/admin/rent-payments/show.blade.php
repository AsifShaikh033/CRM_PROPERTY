@extends('layouts.admin.app')

@section('title', 'Rent Payment Details')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">

    <div>
        <h1 class="page-title mb-1">
            Rent Payment Details
        </h1>

        <div class="text-muted">
            View payment and tenant information
        </div>
    </div>

    <div>

        <a
            href="{{ route('admin.rent-payments.edit', ['rent_payment' => $item->id]) }}"
            class="btn btn-primary"
        >
            Edit Payment
        </a>

        <a
            href="{{ route('admin.rent-payments.index') }}"
            class="btn btn-light ms-2"
        >
            ← Back
        </a>

    </div>

</div>


<div class="row g-4">

    {{-- Main Payment Details --}}
    <div class="col-lg-8">

        <div class="card p-4">

            <div class="d-flex justify-content-between align-items-center mb-4">

                <div>

                    <h4 class="mb-1">
                        Payment #{{ $item->id }}
                    </h4>

                    <div class="text-muted">
                        Rent payment record
                    </div>

                </div>


                @switch($item->status)

                    @case('paid')

                        <span class="badge bg-success fs-6">
                            Paid
                        </span>

                        @break

                    @case('pending')

                        <span class="badge bg-warning text-dark fs-6">
                            Pending
                        </span>

                        @break

                    @case('failed')

                        <span class="badge bg-danger fs-6">
                            Failed
                        </span>

                        @break

                    @case('refunded')

                        <span class="badge bg-info text-dark fs-6">
                            Refunded
                        </span>

                        @break

                    @default

                        <span class="badge bg-secondary fs-6">
                            {{ ucfirst($item->status ?? 'Unknown') }}
                        </span>

                @endswitch

            </div>


            <div class="row g-4">

                {{-- Amount --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Payment Amount
                    </div>

                    <div class="fw-bold fs-3">
                        ₹{{ number_format($item->amount ?? 0, 2) }}
                    </div>

                </div>


                {{-- Payment Date --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Payment Date
                    </div>

                    <div class="fw-semibold">

                        {{ $item->payment_date
                            ? \Carbon\Carbon::parse($item->payment_date)->format('d M Y')
                            : '-'
                        }}

                    </div>

                </div>


                {{-- Tenant --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Tenant
                    </div>

                    <div class="fw-semibold">

                        @if ($item->tenant)

                            {{ $item->tenant->name }}

                        @elseif ($item->tenant_id)

                            Tenant #{{ $item->tenant_id }}

                        @else

                            -

                        @endif

                    </div>

                </div>


                {{-- Tenant Phone --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Tenant Phone
                    </div>

                    <div class="fw-semibold">

                        {{ $item->tenant?->phone ?? '-' }}

                    </div>

                </div>


                {{-- Tenant Email --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Tenant Email
                    </div>

                    <div class="fw-semibold">

                        {{ $item->tenant?->email ?? '-' }}

                    </div>

                </div>


                {{-- Property --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Property
                    </div>

                    <div class="fw-semibold">

                        @if ($item->property)

                            {{ $item->property->name }}

                            @if ($item->property->property_code)

                                <div class="small text-muted">
                                    {{ $item->property->property_code }}
                                </div>

                            @endif

                        @elseif ($item->property_id)

                            Property #{{ $item->property_id }}

                        @else

                            -

                        @endif

                    </div>

                </div>


                {{-- Unit --}}
           

                {{-- Rent Period --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Rent Period
                    </div>

                    <div class="fw-semibold">
                        @php
                            $monthNames = [
                                '1' => 'January',
                                '2' => 'February',
                                '3' => 'March',
                                '4' => 'April',
                                '5' => 'May',
                                '6' => 'June',
                                '7' => 'July',
                                '8' => 'August',
                                '9' => 'September',
                                '10' => 'October',
                                '11' => 'November',
                                '12' => 'December'
                            ];
                        @endphp

                        {{ $monthNames[$item->month] ?? '-' }}

                        @if ($item->month && $item->year)
                            /
                        @endif

                        {{ $item->year ?? '' }}

                    </div>

                </div>


                {{-- Payment Method --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Payment Method
                    </div>

                    <div class="fw-semibold">

                        {{ $item->method
                            ? ucwords(str_replace('_', ' ', $item->method))
                            : '-'
                        }}

                    </div>

                </div>


                {{-- Reference --}}
                <div class="col-md-12">

                    <div class="text-muted small">
                        Payment Reference
                    </div>

                    <div class="fw-semibold">

                        {{ $item->reference ?? '-' }}

                    </div>

                </div>

            </div>

        </div>

    </div>


    {{-- Right Sidebar --}}
    <div class="col-lg-4">


        {{-- Payment Summary --}}
        <div class="card p-4">

            <h5 class="mb-3">
                Payment Summary
            </h5>


            <div class="d-flex justify-content-between mb-3">

                <span class="text-muted">
                    Amount
                </span>

                <strong>
                    ₹{{ number_format($item->amount ?? 0, 2) }}
                </strong>

            </div>


            <div class="d-flex justify-content-between mb-3">

                <span class="text-muted">
                    Method
                </span>

                <strong>

                    {{ $item->method
                        ? ucwords(str_replace('_', ' ', $item->method))
                        : '-'
                    }}

                </strong>

            </div>


            <div class="d-flex justify-content-between">

                <span class="text-muted">
                    Status
                </span>

                <strong>
                    {{ ucfirst($item->status ?? '-') }}
                </strong>

            </div>

        </div>


        {{-- Quick Actions --}}
        <div class="card p-4 mt-4">

            <h5 class="mb-3">
                Quick Actions
            </h5>


            <div class="d-grid gap-2">

                <a
                    href="{{ route('admin.rent-payments.edit', ['rent_payment' => $item->id]) }}"
                    class="btn btn-outline-primary"
                >
                    Edit Payment
                </a>


                @if ($item->tenant?->phone)

                    <a
                        href="tel:{{ $item->tenant->phone }}"
                        class="btn btn-outline-success"
                    >
                        Call Tenant
                    </a>

                @endif


                @if ($item->tenant?->email)

                    <a
                        href="mailto:{{ $item->tenant->email }}"
                        class="btn btn-outline-info"
                    >
                        Email Tenant
                    </a>

                @endif


                <form
                    method="POST"
                    action="{{ route('admin.rent-payments.destroy', ['rent_payment' => $item->id]) }}"
                    onsubmit="return confirm('Are you sure you want to delete this payment?')"
                >

                    @csrf

                    @method('DELETE')

                    <button
                        type="submit"
                        class="btn btn-outline-danger w-100"
                    >
                        Delete Payment
                    </button>

                </form>

            </div>

        </div>


        {{-- Record Information --}}
        <div class="card p-4 mt-4">

            <h5 class="mb-3">
                Record Information
            </h5>


            <div class="mb-3">

                <div class="text-muted small">
                    Payment ID
                </div>

                <strong>
                    #{{ $item->id }}
                </strong>

            </div>


            <div class="mb-3">

                <div class="text-muted small">
                    Created
                </div>

                <strong>
                    {{ $item->created_at?->format('d M Y, h:i A') ?? '-' }}
                </strong>

            </div>


            <div>

                <div class="text-muted small">
                    Last Updated
                </div>

                <strong>
                    {{ $item->updated_at?->format('d M Y, h:i A') ?? '-' }}
                </strong>

            </div>

        </div>

    </div>

</div>

@endsection