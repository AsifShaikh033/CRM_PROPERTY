@extends('layouts.admin.app')

@section('title', 'Agents')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">

    <div>

        <h1 class="page-title mb-1">
            Agents
        </h1>

        <div class="text-muted">
            Manage property agents
        </div>

    </div>


    <a
        href="{{ route('admin.agents.create') }}"
        class="btn btn-primary"
    >
        + Add Agent
    </a>

</div>


<div class="card p-4">

    <div class="table-responsive">

        <table class="table table-hover align-middle">

            <thead>

                <tr>

                    <th width="70">
                        ID
                    </th>

                    <th>
                        Agent
                    </th>

                    <th>
                        Email
                    </th>

                    <th>
                        Phone
                    </th>

                    <th>
                        Status
                    </th>

                    <th>
                        Created
                    </th>

                    <th width="250">
                        Actions
                    </th>

                </tr>

            </thead>


            <tbody>

                @forelse ($items as $item)

                    <tr>

                        <td>
                            {{ $item->id }}
                        </td>


                        <td>

                            <strong>
                                {{ $item->name ?? 'Record' }}
                            </strong>

                        </td>


                        <td>
                            {{ $item->email ?? '-' }}
                        </td>


                        <td>
                            {{ $item->phone ?? '-' }}
                        </td>


                        <td>

                            @if ($item->status === 'active')

                                <span class="badge bg-success">
                                    Active
                                </span>

                            @else

                                <span class="badge bg-secondary">
                                    {{ ucfirst($item->status ?? 'Inactive') }}
                                </span>

                            @endif

                        </td>


                        <td>
                            {{ $item->created_at?->format('d M Y') ?? '-' }}
                        </td>


                        <td>

                            <a
                                href="{{ route('admin.agents.show', ['agent' => $item->id]) }}"
                                class="btn btn-sm btn-outline-primary"
                            >
                                View
                            </a>


                            <a
                                href="{{ route('admin.agents.edit', ['agent' => $item->id]) }}"
                                class="btn btn-sm btn-outline-secondary"
                            >
                                Edit
                            </a>


                            <form
                                action="{{ route('admin.agents.destroy', ['agent' => $item->id]) }}"
                                method="POST"
                                class="d-inline"
                                onsubmit="return confirm('Are you sure you want to delete this agent?')"
                            >

                                @csrf

                                @method('DELETE')

                                <button
                                    type="submit"
                                    class="btn btn-sm btn-outline-danger"
                                >
                                    Delete
                                </button>

                            </form>

                        </td>

                    </tr>

                @empty

                    <tr>

                        <td
                            colspan="7"
                            class="text-center py-5"
                        >

                            <div class="text-muted mb-3">
                                No agents found.
                            </div>

                            <a
                                href="{{ route('admin.agents.create') }}"
                                class="btn btn-primary btn-sm"
                            >
                                + Add Agent
                            </a>

                        </td>

                    </tr>

                @endforelse

            </tbody>

        </table>

    </div>


    <div class="mt-3">

        {{ $items->links() }}

    </div>

</div>

@endsection