@extends('layouts.admin.app')

@section('title', 'Rental Agreements')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">

    <div>

        <h1 class="page-title mb-1">
            Rental Agreements
        </h1>

        <div class="text-muted">
            Manage tenant rental agreements and contracts
        </div>

    </div>


    <a
        href="{{ route('admin.agreements.create') }}"
        class="btn btn-primary"
    >
        + Add Agreement
    </a>

</div>


<div class="card p-4">

    <div class="table-responsive">

        <table class="table table-hover align-middle">

            <thead>

                <tr>

                    <th>
                        ID
                    </th>

                    <th>
                        Property
                    </th>

                    <th>
                        Tenant
                    </th>

                    <th>
                        Agreement Period
                    </th>

                    <th>
                        Rent
                    </th>

                    <th>
                        Deposit
                    </th>

                    <th>
                        Status
                    </th>

                    <th>
                        Actions
                    </th>

                </tr>

            </thead>


            <tbody>

                @forelse ($items as $item)

                    <tr>

                        <td>
                            #{{ $item->id }}
                        </td>


                        {{-- Property --}}
                        <td>

                            @if ($item->property)

                                <strong>
                                    {{ $item->property->name }}
                                </strong>

                                @if ($item->property->property_code)

                                    <div class="small text-muted">
                                        {{ $item->property->property_code }}
                                    </div>

                                @endif

                            @elseif ($item->property_id)

                                Property #{{ $item->property_id }}

                            @else

                                -

                            @endif

                        </td>


                        {{-- Tenant --}}
                        <td>

                            @if ($item->tenant)

                                <strong>
                                    {{ $item->tenant->name }}
                                </strong>

                                @if ($item->tenant->phone)

                                    <div class="small text-muted">
                                        {{ $item->tenant->phone }}
                                    </div>

                                @endif

                            @elseif ($item->tenant_id)

                                Tenant #{{ $item->tenant_id }}

                            @else

                                -

                            @endif

                        </td>


                        {{-- Agreement Period --}}
                        <td>

                            <div>
                                {{ $item->start_date
                                    ? \Carbon\Carbon::parse($item->start_date)->format('d M Y')
                                    : '-'
                                }}
                            </div>

                            <small class="text-muted">
                                to
                                {{ $item->end_date
                                    ? \Carbon\Carbon::parse($item->end_date)->format('d M Y')
                                    : '-'
                                }}
                            </small>

                        </td>


                        {{-- Rent --}}
                        <td>

                            <strong>
                                ₹{{ number_format($item->rent ?? 0, 2) }}
                            </strong>

                            <div class="small text-muted">
                                Monthly
                            </div>

                        </td>


                        {{-- Deposit --}}
                        <td>

                            ₹{{ number_format($item->deposit ?? 0, 2) }}

                        </td>


                        {{-- Status --}}
                        <td>

                            @switch($item->status)

                                @case('draft')

                                    <span class="badge bg-secondary">
                                        Draft
                                    </span>

                                    @break

                                @case('active')

                                    <span class="badge bg-success">
                                        Active
                                    </span>

                                    @break

                                @case('expired')

                                    <span class="badge bg-warning text-dark">
                                        Expired
                                    </span>

                                    @break

                                @case('terminated')

                                    <span class="badge bg-danger">
                                        Terminated
                                    </span>

                                    @break

                                @default

                                    <span class="badge bg-secondary">
                                        {{ ucfirst($item->status ?? 'Unknown') }}
                                    </span>

                            @endswitch

                        </td>


                        {{-- Actions --}}
                        <td>

                            <a
                                href="{{ route('admin.agreements.show', ['agreement' => $item->id]) }}"
                                class="btn btn-sm btn-outline-primary"
                            >
                                View
                            </a>


                            <a
                                href="{{ route('admin.agreements.edit', ['agreement' => $item->id]) }}"
                                class="btn btn-sm btn-outline-secondary"
                            >
                                Edit
                            </a>


                            <form
                                action="{{ route('admin.agreements.destroy', ['agreement' => $item->id]) }}"
                                method="POST"
                                class="d-inline"
                                onsubmit="return confirm('Are you sure you want to delete this rental agreement?')"
                            >

                                @csrf

                                @method('DELETE')

                                <button
                                    type="submit"
                                    class="btn btn-sm btn-outline-danger"
                                >
                                    Delete
                                </button>

                            </form>

                        </td>

                    </tr>


                @empty

                    <tr>

                        <td
                            colspan="8"
                            class="text-center py-5"
                        >

                            <div class="text-muted mb-3">
                                No rental agreements found.
                            </div>

                            <a
                                href="{{ route('admin.agreements.create') }}"
                                class="btn btn-primary btn-sm"
                            >
                                + Add Agreement
                            </a>

                        </td>

                    </tr>

                @endforelse

            </tbody>

        </table>

    </div>


    <div class="mt-3">

        {{ $items->links() }}

    </div>

</div>

@endsection