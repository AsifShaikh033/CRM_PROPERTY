@extends('layouts.admin.app')

@section('title', 'Edit Rental Agreement')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">

    <div>
        <h1 class="page-title mb-1">
            Edit Rental Agreement
        </h1>

        <div class="text-muted">
            Update rental agreement information
        </div>
    </div>

    <div>

        <a
            href="{{ route('admin.agreements.show', ['agreement' => $item->id]) }}"
            class="btn btn-outline-primary"
        >
            View Agreement
        </a>

        <a
            href="{{ route('admin.agreements.index') }}"
            class="btn btn-light ms-2"
        >
            ← Back
        </a>

    </div>

</div>


<form
    method="POST"
    action="{{ route('admin.agreements.update', ['agreement' => $item->id]) }}"
>

    @csrf

    @method('PUT')


    <div class="card p-4">

        <div class="row g-3">


            {{-- Property --}}
            <div class="col-md-6">

                <label class="form-label">
                    Property
                </label>

                <select
                    name="property_id"
                    class="form-select @error('property_id') is-invalid @enderror"
                >

                    <option value="">
                        Select Property
                    </option>

                    @foreach ($properties ?? [] as $property)

                        <option
                            value="{{ $property->id }}"
                            {{ old('property_id', $item->property_id) == $property->id ? 'selected' : '' }}
                        >
                            {{ $property->name }}

                            @if ($property->property_code)
                                ({{ $property->property_code }})
                            @endif

                        </option>

                    @endforeach

                </select>

                @error('property_id')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Unit --}}
            <!-- <div class="col-md-6">

                <label class="form-label">
                    Unit
                </label>

                <select
                    name="unit_id"
                    class="form-select @error('unit_id') is-invalid @enderror"
                >

                    <option value="">
                        Select Unit
                    </option>

                    @foreach ($units ?? [] as $unit)

                        <option
                            value="{{ $unit->id }}"
                            {{ old('unit_id', $item->unit_id) == $unit->id ? 'selected' : '' }}
                        >
                            {{ $unit->name ?? $unit->unit_number ?? 'Unit #' . $unit->id }}
                        </option>

                    @endforeach

                </select>

                @error('unit_id')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div> -->


            {{-- Tenant --}}
            <div class="col-md-6">

                <label class="form-label">
                    Tenant
                </label>

                <select
                    name="tenant_id"
                    class="form-select @error('tenant_id') is-invalid @enderror"
                >

                    <option value="">
                        Select Tenant
                    </option>

                    @foreach ($tenants ?? [] as $tenant)

                        <option
                            value="{{ $tenant->id }}"
                            {{ old('tenant_id', $item->tenant_id) == $tenant->id ? 'selected' : '' }}
                        >
                            {{ $tenant->name }}

                            @if ($tenant->phone)
                                - {{ $tenant->phone }}
                            @endif

                        </option>

                    @endforeach

                </select>

                @error('tenant_id')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Start Date --}}
            <div class="col-md-3">

                <label class="form-label">
                    Start Date
                    <span class="text-danger">*</span>
                </label>

                <input
                    type="date"
                    name="start_date"
                    value="{{ old('start_date', $item->start_date ? \Carbon\Carbon::parse($item->start_date)->format('Y-m-d') : '') }}"
                    class="form-control @error('start_date') is-invalid @enderror"
                    required
                >

                @error('start_date')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- End Date --}}
            <div class="col-md-3">

                <label class="form-label">
                    End Date
                    <span class="text-danger">*</span>
                </label>

                <input
                    type="date"
                    name="end_date"
                    value="{{ old('end_date', $item->end_date ? \Carbon\Carbon::parse($item->end_date)->format('Y-m-d') : '') }}"
                    class="form-control @error('end_date') is-invalid @enderror"
                    required
                >

                @error('end_date')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Monthly Rent --}}
            <div class="col-md-3">

                <label class="form-label">
                    Monthly Rent
                    <span class="text-danger">*</span>
                </label>

                <div class="input-group">

                    <span class="input-group-text">
                        ₹
                    </span>

                    <input
                        type="number"
                        name="rent"
                        value="{{ old('rent', $item->rent ?? 0) }}"
                        min="0"
                        step="0.01"
                        class="form-control @error('rent') is-invalid @enderror"
                        required
                    >

                </div>

                @error('rent')
                    <div class="text-danger small mt-1">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Security Deposit --}}
            <div class="col-md-3">

                <label class="form-label">
                    Security Deposit
                    <span class="text-danger">*</span>
                </label>

                <div class="input-group">

                    <span class="input-group-text">
                        ₹
                    </span>

                    <input
                        type="number"
                        name="deposit"
                        value="{{ old('deposit', $item->deposit ?? 0) }}"
                        min="0"
                        step="0.01"
                        class="form-control @error('deposit') is-invalid @enderror"
                        required
                    >

                </div>

                @error('deposit')
                    <div class="text-danger small mt-1">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Status --}}
            <div class="col-md-4">

                <label class="form-label">
                    Status
                    <span class="text-danger">*</span>
                </label>

                <select
                    name="status"
                    class="form-select @error('status') is-invalid @enderror"
                    required
                >

                    <option
                        value="draft"
                        {{ old('status', $item->status) === 'draft' ? 'selected' : '' }}
                    >
                        Draft
                    </option>

                    <option
                        value="active"
                        {{ old('status', $item->status) === 'active' ? 'selected' : '' }}
                    >
                        Active
                    </option>

                    <option
                        value="expired"
                        {{ old('status', $item->status) === 'expired' ? 'selected' : '' }}
                    >
                        Expired
                    </option>

                    <option
                        value="terminated"
                        {{ old('status', $item->status) === 'terminated' ? 'selected' : '' }}
                    >
                        Terminated
                    </option>

                </select>

                @error('status')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>

        </div>


        {{-- Buttons --}}
        <div class="mt-4 pt-3 border-top">

            <button
                type="submit"
                class="btn btn-primary"
            >
                Update Rental Agreement
            </button>

            <a
                href="{{ route('admin.agreements.index') }}"
                class="btn btn-light ms-2"
            >
                Cancel
            </a>

        </div>

    </div>

</form>

@endsection