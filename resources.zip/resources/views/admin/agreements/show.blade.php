@extends('layouts.admin.app')

@section('title', 'Rental Agreement Details')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">

    <div>
        <h1 class="page-title mb-1">
            Rental Agreement Details
        </h1>

        <div class="text-muted">
            View rental agreement and tenancy information
        </div>
    </div>

    <div>

        <a
            href="{{ route('admin.agreements.edit', ['agreement' => $item->id]) }}"
            class="btn btn-primary"
        >
            Edit Agreement
        </a>

        <a
            href="{{ route('admin.agreements.index') }}"
            class="btn btn-light ms-2"
        >
            ← Back
        </a>

    </div>

</div>


<div class="row g-4">

    {{-- Agreement Information --}}
    <div class="col-lg-8">

        <div class="card p-4">

            <div class="d-flex justify-content-between align-items-center mb-4">

                <div>

                    <h4 class="mb-1">
                        Agreement #{{ $item->id }}
                    </h4>

                    <div class="text-muted">
                        Rental agreement information
                    </div>

                </div>


                {{-- Status --}}
                @switch($item->status)

                    @case('draft')

                        <span class="badge bg-secondary">
                            Draft
                        </span>

                        @break

                    @case('active')

                        <span class="badge bg-success">
                            Active
                        </span>

                        @break

                    @case('expired')

                        <span class="badge bg-warning text-dark">
                            Expired
                        </span>

                        @break

                    @case('terminated')

                        <span class="badge bg-danger">
                            Terminated
                        </span>

                        @break

                    @default

                        <span class="badge bg-secondary">
                            {{ ucfirst($item->status ?? 'Unknown') }}
                        </span>

                @endswitch

            </div>


            <div class="row g-4">

                {{-- Property --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Property
                    </div>

                    <div class="fw-semibold">

                        @if ($item->property)

                            {{ $item->property->name }}

                            @if ($item->property->property_code)

                                <div class="small text-muted">
                                    Code:
                                    {{ $item->property->property_code }}
                                </div>

                            @endif

                        @elseif ($item->property_id)

                            Property #{{ $item->property_id }}

                        @else

                            -

                        @endif

                    </div>

                </div>


                {{-- Unit --}}
                <!-- <div class="col-md-6">

                    <div class="text-muted small">
                        Unit
                    </div>

                    <div class="fw-semibold">

                        @if ($item->unit)

                            {{ $item->unit->name ?? $item->unit->unit_number ?? 'Unit #' . $item->unit->id }}

                        @elseif ($item->unit_id)

                            Unit #{{ $item->unit_id }}

                        @else

                            -

                        @endif

                    </div>

                </div> -->


                {{-- Tenant --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Tenant
                    </div>

                    <div class="fw-semibold">

                        @if ($item->tenant)

                            {{ $item->tenant->name }}

                        @elseif ($item->tenant_id)

                            Tenant #{{ $item->tenant_id }}

                        @else

                            -

                        @endif

                    </div>

                </div>


                {{-- Tenant Phone --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Tenant Phone
                    </div>

                    <div class="fw-semibold">

                        @if ($item->tenant?->phone)

                            {{ $item->tenant->phone }}

                        @else

                            -

                        @endif

                    </div>

                </div>


                {{-- Tenant Email --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Tenant Email
                    </div>

                    <div class="fw-semibold">

                        @if ($item->tenant?->email)

                            {{ $item->tenant->email }}

                        @else

                            -

                        @endif

                    </div>

                </div>


                {{-- Start Date --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Start Date
                    </div>

                    <div class="fw-semibold">

                        {{ $item->start_date
                            ? \Carbon\Carbon::parse($item->start_date)->format('d M Y')
                            : '-'
                        }}

                    </div>

                </div>


                {{-- End Date --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        End Date
                    </div>

                    <div class="fw-semibold">

                        {{ $item->end_date
                            ? \Carbon\Carbon::parse($item->end_date)->format('d M Y')
                            : '-'
                        }}

                    </div>

                </div>


                {{-- Monthly Rent --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Monthly Rent
                    </div>

                    <div class="fw-semibold fs-5">
                        ₹{{ number_format($item->rent ?? 0, 2) }}
                    </div>

                </div>


                {{-- Security Deposit --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Security Deposit
                    </div>

                    <div class="fw-semibold fs-5">
                        ₹{{ number_format($item->deposit ?? 0, 2) }}
                    </div>

                </div>


                {{-- Agreement Duration --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Agreement Duration
                    </div>

                    <div class="fw-semibold">

                        @if ($item->start_date && $item->end_date)

                            {{ \Carbon\Carbon::parse($item->start_date)->diffInMonths(
                                \Carbon\Carbon::parse($item->end_date)
                            ) }}
                            Months

                        @else

                            -

                        @endif

                    </div>

                </div>

            </div>

        </div>

    </div>


    {{-- Sidebar --}}
    <div class="col-lg-4">


        {{-- Quick Actions --}}
        <div class="card p-4">

            <h5 class="mb-3">
                Quick Actions
            </h5>


            <div class="d-grid gap-2">

                <a
                    href="{{ route('admin.agreements.edit', ['agreement' => $item->id]) }}"
                    class="btn btn-outline-primary"
                >
                    Edit Agreement
                </a>


                @if ($item->tenant?->phone)

                    <a
                        href="tel:{{ $item->tenant->phone }}"
                        class="btn btn-outline-success"
                    >
                        Call Tenant
                    </a>

                @endif


                @if ($item->tenant?->email)

                    <a
                        href="mailto:{{ $item->tenant->email }}"
                        class="btn btn-outline-info"
                    >
                        Email Tenant
                    </a>

                @endif


                <form
                    method="POST"
                    action="{{ route('admin.agreements.destroy', ['agreement' => $item->id]) }}"
                    onsubmit="return confirm('Are you sure you want to delete this rental agreement?')"
                >

                    @csrf

                    @method('DELETE')

                    <button
                        type="submit"
                        class="btn btn-outline-danger w-100"
                    >
                        Delete Agreement
                    </button>

                </form>

            </div>

        </div>


        {{-- Record Information --}}
        <div class="card p-4 mt-4">

            <h5 class="mb-3">
                Record Information
            </h5>


            <div class="mb-3">

                <div class="text-muted small">
                    Agreement ID
                </div>

                <strong>
                    #{{ $item->id }}
                </strong>

            </div>


            <div class="mb-3">

                <div class="text-muted small">
                    Created
                </div>

                <strong>
                    {{ $item->created_at?->format('d M Y, h:i A') ?? '-' }}
                </strong>

            </div>


            <div>

                <div class="text-muted small">
                    Last Updated
                </div>

                <strong>
                    {{ $item->updated_at?->format('d M Y, h:i A') ?? '-' }}
                </strong>

            </div>

        </div>

    </div>

</div>

@endsection