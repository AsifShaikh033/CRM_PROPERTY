@extends('layouts.admin.app')

@section('title', 'Edit Owner')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">

    <div>
        <h1 class="page-title mb-1">
            Edit Owner
        </h1>

        <div class="text-muted">
            Update owner information
        </div>
    </div>

    <div>

        <a
            href="{{ route('admin.owners.show', ['owner' => $item->id]) }}"
            class="btn btn-outline-primary"
        >
            View Owner
        </a>

        <a
            href="{{ route('admin.owners.index') }}"
            class="btn btn-light ms-2"
        >
            ← Back
        </a>

    </div>

</div>


<form
    method="POST"
    action="{{ route('admin.owners.update', ['owner' => $item->id]) }}"
>

    @csrf

    @method('PUT')


    <div class="card p-4">

        <div class="row g-3">

            {{-- Owner Name --}}
            <div class="col-md-6">

                <label class="form-label">
                    Owner Name
                    <span class="text-danger">*</span>
                </label>

                <input
                    type="text"
                    name="name"
                    value="{{ old('name', $item->name) }}"
                    class="form-control @error('name') is-invalid @enderror"
                    placeholder="Enter owner name"
                    required
                >

                @error('name')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Phone --}}
            <div class="col-md-3">

                <label class="form-label">
                    Phone
                </label>

                <input
                    type="text"
                    name="phone"
                    value="{{ old('phone', $item->phone) }}"
                    class="form-control @error('phone') is-invalid @enderror"
                    placeholder="Phone number"
                >

                @error('phone')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Email --}}
            <div class="col-md-3">

                <label class="form-label">
                    Email
                </label>

                <input
                    type="email"
                    name="email"
                    value="{{ old('email', $item->email) }}"
                    class="form-control @error('email') is-invalid @enderror"
                    placeholder="owner@example.com"
                >

                @error('email')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Address --}}
            <div class="col-md-12">

                <label class="form-label">
                    Address
                </label>

                <textarea
                    name="address"
                    rows="3"
                    class="form-control @error('address') is-invalid @enderror"
                    placeholder="Enter owner address"
                >{{ old('address', $item->address) }}</textarea>

                @error('address')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- City --}}
            <div class="col-md-4">

                <label class="form-label">
                    City
                </label>

                <input
                    type="text"
                    name="city"
                    value="{{ old('city', $item->city) }}"
                    class="form-control"
                    placeholder="City"
                >

            </div>


            {{-- State --}}
            <div class="col-md-4">

                <label class="form-label">
                    State
                </label>

                <input
                    type="text"
                    name="state"
                    value="{{ old('state', $item->state) }}"
                    class="form-control"
                    placeholder="State"
                >

            </div>


            {{-- Country --}}
            <div class="col-md-4">

                <label class="form-label">
                    Country
                </label>

                <input
                    type="text"
                    name="country"
                    value="{{ old('country', $item->country ?? 'India') }}"
                    class="form-control"
                    placeholder="Country"
                >

            </div>


            {{-- Status --}}
            <div class="col-md-4">

                <label class="form-label">
                    Status
                    <span class="text-danger">*</span>
                </label>

                <select
                    name="status"
                    class="form-select @error('status') is-invalid @enderror"
                    required
                >

                    <option
                        value="active"
                        {{ old('status', $item->status) === 'active' ? 'selected' : '' }}
                    >
                        Active
                    </option>

                    <option
                        value="inactive"
                        {{ old('status', $item->status) === 'inactive' ? 'selected' : '' }}
                    >
                        Inactive
                    </option>

                </select>

                @error('status')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror

            </div>


            {{-- Notes --}}
            <div class="col-md-12">

                <label class="form-label">
                    Notes
                </label>

                <textarea
                    name="notes"
                    rows="4"
                    class="form-control"
                    placeholder="Additional notes about the owner"
                >{{ old('notes', $item->notes) }}</textarea>

            </div>

        </div>


        {{-- Buttons --}}
        <div class="mt-4 pt-3 border-top">

            <button
                type="submit"
                class="btn btn-primary"
            >
                Update Owner
            </button>

            <a
                href="{{ route('admin.owners.index') }}"
                class="btn btn-light ms-2"
            >
                Cancel
            </a>

        </div>

    </div>

</form>

@endsection