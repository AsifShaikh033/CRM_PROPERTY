@extends('layouts.admin.app')

@section('title', 'Owners')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">

    <div>
        <h1 class="page-title mb-1">
            Owners
        </h1>

        <div class="text-muted">
            Manage property owners
        </div>
    </div>

    <a
        href="{{ route('admin.owners.create') }}"
        class="btn btn-primary"
    >
        + Add Owner
    </a>

</div>


<div class="card p-4">

    <div class="table-responsive">

        <table class="table table-hover align-middle">

            <thead>

                <tr>

                    <th width="80">
                        ID
                    </th>

                    <th>
                        Owner
                    </th>

                    <th>
                        Email
                    </th>

                    <th>
                        Phone
                    </th>

                    <th>
                        Status
                    </th>

                    <th>
                        Created
                    </th>

                    <th width="220">
                        Actions
                    </th>

                </tr>

            </thead>


            <tbody>

                @forelse ($items as $item)

                    <tr>

                        <td>
                            {{ $item->id }}
                        </td>


                        <td>

                            <strong>
                                {{ $item->name }}
                            </strong>

                        </td>


                        <td>
                            {{ $item->email ?? '-' }}
                        </td>


                        <td>
                            {{ $item->phone ?? '-' }}
                        </td>


                        <td>

                            @if ($item->status === 'active')

                                <span class="badge bg-success">
                                    Active
                                </span>

                            @else

                                <span class="badge bg-secondary">
                                    Inactive
                                </span>

                            @endif

                        </td>


                        <td>
                            {{ $item->created_at?->format('d M Y') }}
                        </td>


                        <td>

                            <a
                                href="{{ route('admin.owners.show', ['owner' => $item->id]) }}"
                                class="btn btn-sm btn-outline-primary"
                            >
                                View
                            </a>


                            <a
                                href="{{ route('admin.owners.edit', ['owner' => $item->id]) }}"
                                class="btn btn-sm btn-outline-secondary"
                            >
                                Edit
                            </a>


                            <form
                                action="{{ route('admin.owners.destroy', ['owner' => $item->id]) }}"
                                method="POST"
                                class="d-inline"
                                onsubmit="return confirm('Are you sure you want to delete this owner?')"
                            >

                                @csrf

                                @method('DELETE')

                                <button
                                    type="submit"
                                    class="btn btn-sm btn-outline-danger"
                                >
                                    Delete
                                </button>

                            </form>

                        </td>

                    </tr>

                @empty

                    <tr>

                        <td
                            colspan="7"
                            class="text-center py-5"
                        >

                            <div class="text-muted mb-3">
                                No owners found.
                            </div>

                            <a
                                href="{{ route('admin.owners.create') }}"
                                class="btn btn-primary btn-sm"
                            >
                                + Add Owner
                            </a>

                        </td>

                    </tr>

                @endforelse

            </tbody>

        </table>

    </div>


    <div class="mt-3">

        {{ $items->links() }}

    </div>

</div>

@endsection