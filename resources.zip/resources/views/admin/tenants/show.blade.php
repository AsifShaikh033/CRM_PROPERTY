@extends('layouts.admin.app')

@section('title', 'Tenant Details')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">

    <div>
        <h1 class="page-title mb-1">
            Tenant Details
        </h1>

        <div class="text-muted">
            View tenant information
        </div>
    </div>

    <div>

        <a
            href="{{ route('admin.tenants.edit', ['tenant' => $item->id]) }}"
            class="btn btn-primary"
        >
            Edit Tenant
        </a>

        <a
            href="{{ route('admin.tenants.index') }}"
            class="btn btn-light ms-2"
        >
            ← Back
        </a>

    </div>

</div>


<div class="row g-4">

    {{-- Tenant Information --}}
    <div class="col-lg-8">

        <div class="card p-4">

            <div class="d-flex justify-content-between align-items-center mb-4">

                <div>

                    <h4 class="mb-1">
                        {{ $item->name ?? '-' }}
                    </h4>

                    <div class="text-muted">
                        Tenant #{{ $item->id }}
                    </div>

                </div>


                @if ($item->status === 'active')

                    <span class="badge bg-success">
                        Active
                    </span>

                @else

                    <span class="badge bg-secondary">
                        {{ ucfirst($item->status ?? 'Inactive') }}
                    </span>

                @endif

            </div>


            <div class="row g-4">

                {{-- Name --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Tenant Name
                    </div>

                    <div class="fw-semibold">
                        {{ $item->name ?? '-' }}
                    </div>

                </div>


                {{-- Phone --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Phone
                    </div>

                    <div class="fw-semibold">
                        {{ $item->phone ?? '-' }}
                    </div>

                </div>


                {{-- Email --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Email
                    </div>

                    <div class="fw-semibold">
                        {{ $item->email ?? '-' }}
                    </div>

                </div>


                {{-- City --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        City
                    </div>

                    <div class="fw-semibold">
                        {{ $item->city ?? '-' }}
                    </div>

                </div>


                {{-- State --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        State
                    </div>

                    <div class="fw-semibold">
                        {{ $item->state ?? '-' }}
                    </div>

                </div>


                {{-- Country --}}
                <div class="col-md-6">

                    <div class="text-muted small">
                        Country
                    </div>

                    <div class="fw-semibold">
                        {{ $item->country ?? '-' }}
                    </div>

                </div>


                {{-- Address --}}
                <div class="col-md-12">

                    <div class="text-muted small">
                        Address
                    </div>

                    <div class="fw-semibold">
                        {{ $item->address ?? '-' }}
                    </div>

                </div>


                {{-- Notes --}}
                <div class="col-md-12">

                    <div class="text-muted small">
                        Notes
                    </div>

                    <div>
                        {{ $item->notes ?? 'No notes available.' }}
                    </div>

                </div>

            </div>

        </div>

    </div>


    {{-- Right Side --}}
    <div class="col-lg-4">

        {{-- Quick Actions --}}
        <div class="card p-4">

            <h5 class="mb-3">
                Quick Actions
            </h5>

            <div class="d-grid gap-2">

                <a
                    href="{{ route('admin.tenants.edit', ['tenant' => $item->id]) }}"
                    class="btn btn-outline-primary"
                >
                    Edit Tenant
                </a>


                <form
                    method="POST"
                    action="{{ route('admin.tenants.destroy', ['tenant' => $item->id]) }}"
                    onsubmit="return confirm('Are you sure you want to delete this tenant?')"
                >

                    @csrf

                    @method('DELETE')

                    <button
                        type="submit"
                        class="btn btn-outline-danger w-100"
                    >
                        Delete Tenant
                    </button>

                </form>

            </div>

        </div>


        {{-- Record Information --}}
        <div class="card p-4 mt-4">

            <h5 class="mb-3">
                Record Information
            </h5>


            <div class="mb-3">

                <div class="text-muted small">
                    Tenant ID
                </div>

                <strong>
                    #{{ $item->id }}
                </strong>

            </div>


            <div class="mb-3">

                <div class="text-muted small">
                    Created
                </div>

                <strong>
                    {{ $item->created_at?->format('d M Y, h:i A') ?? '-' }}
                </strong>

            </div>


            <div>

                <div class="text-muted small">
                    Last Updated
                </div>

                <strong>
                    {{ $item->updated_at?->format('d M Y, h:i A') ?? '-' }}
                </strong>

            </div>

        </div>

    </div>

</div>

@endsection